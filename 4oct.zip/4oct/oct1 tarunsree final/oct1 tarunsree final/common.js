// JavaScript source code
< !doctype html >
    <html>
        <head>
            
                <title>My Web Page</title>
                <script>
                    alert('hello world!');
</script>
</head>
        </html>
