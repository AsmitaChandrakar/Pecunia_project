﻿using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting Employees from Employees collection.
    /// </summary>
    public class EmployeeBL : BLBase<Employee>, IEmployeeBL, IDisposable
    {
        //fields
        EmployeeDALBase EmployeeDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public EmployeeBL()
        {
            this.EmployeeDAL = new EmployeeDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Employee entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetEmployeeByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.EmployeeID != entityObject.EmployeeID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new Employee to Employees collection.
        /// </summary>
        /// <param name="newEmployee">Contains the Employee details to be added.</param>
        /// <returns>Determinates whether the new Employee is added.</returns>
        public async Task<bool> AddEmployeeBL(Employee newEmployee)
        {
            bool EmployeeAdded = false;
            try
            {
                if (await Validate(newEmployee))
                {
                    await Task.Run(() =>
                    {
                        this.EmployeeDAL.AddEmployeeDAL(newEmployee);
                        EmployeeAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return EmployeeAdded;
        }

        /// <summary>
        /// Gets all Employees from the collection.
        /// </summary>
        /// <returns>Returns list of all Employees.</returns>
        public async Task<List<Employee>> GetAllEmployeesBL()
        {
            List<Employee> EmployeesList = null;
            try
            {
                await Task.Run(() =>
                {
                    EmployeesList = EmployeeDAL.GetAllEmployeesDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return EmployeesList;
        }

        /// <summary>
        /// Gets Employee based on EmployeeID.
        /// </summary>
        /// <param name="searchEmployeeID">Represents EmployeeID to search.</param>
        /// <returns>Returns Employee object.</returns>
        public async Task<Employee> GetEmployeeByEmployeeIDBL(Guid searchEmployeeID)
        {
            Employee matchingEmployee = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingEmployee = EmployeeDAL.GetEmployeeByEmployeeIDDAL(searchEmployeeID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingEmployee;
        }

        /// <summary>
        /// Gets Employee based on EmployeeName.
        /// </summary>
        /// <param name="EmployeeName">Represents EmployeeName to search.</param>
        /// <returns>Returns Employee object.</returns>
        public async Task<List<Employee>> GetEmployeesByNameBL(string EmployeeName)
        {
            List<Employee> matchingEmployees = new List<Employee>();
            try
            {
                await Task.Run(() =>
                {
                    matchingEmployees = EmployeeDAL.GetEmployeesByNameDAL(EmployeeName);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingEmployees;
        }

        /// <summary>
        /// Gets Employee based on Email and Password.
        /// </summary>
        /// <param name="email">Represents Employee's Email Address.</param>
        /// <returns>Returns Employee object.</returns>
        public async Task<Employee> GetEmployeeByEmailBL(string email)
        {
            Employee matchingEmployee = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingEmployee = EmployeeDAL.GetEmployeeByEmailDAL(email);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingEmployee;
        }

        /// <summary>
        /// Gets Employee based on Password.
        /// </summary>
        /// <param name="email">Represents Employee's Email Address.</param>
        /// <param name="password">Represents Employee's Password.</param>
        /// <returns>Returns Employee object.</returns>
        public async Task<Employee> GetEmployeeByEmailAndPasswordBL(string email, string password)
        {
            Employee matchingEmployee = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingEmployee = EmployeeDAL.GetEmployeeByEmailAndPasswordDAL(email, password);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingEmployee;
        }

        /// <summary>
        /// Updates Employee based on EmployeeID.
        /// </summary>
        /// <param name="updateEmployee">Represents Employee details including EmployeeID, EmployeeName etc.</param>
        /// <returns>Determinates whether the existing Employee is updated.</returns>
        public async Task<bool> UpdateEmployeeBL(Employee updateEmployee)
        {
            bool EmployeeUpdated = false;
            try
            {
                if ((await Validate(updateEmployee)) && (await GetEmployeeByEmployeeIDBL(updateEmployee.EmployeeID)) != null)
                {
                    this.EmployeeDAL.UpdateEmployeeDAL(updateEmployee);
                    EmployeeUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return EmployeeUpdated;
        }

        /// <summary>
        /// Deletes Employee based on EmployeeID.
        /// </summary>
        /// <param name="deleteEmployeeID">Represents EmployeeID to delete.</param>
        /// <returns>Determinates whether the existing Employee is updated.</returns>
        public async Task<bool> DeleteEmployeeBL(Guid deleteEmployeeID)
        {
            bool EmployeeDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    EmployeeDeleted = EmployeeDAL.DeleteEmployeeDAL(deleteEmployeeID);
                    Serialize();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return EmployeeDeleted;
        }

        /// <summary>
        /// Updates Employee's password based on EmployeeID.
        /// </summary>
        /// <param name="updateEmployee">Represents Employee details including EmployeeID, Password.</param>
        /// <returns>Determinates whether the existing Employee's password is updated.</returns>
        public async Task<bool> UpdateEmployeePasswordBL(Employee updateEmployee)
        {
            bool passwordUpdated = false;
            try
            {
                if ((await Validate(updateEmployee)) && (await GetEmployeeByEmployeeIDBL(updateEmployee.EmployeeID)) != null)
                {
                    this.EmployeeDAL.UpdateEmployeePasswordDAL(updateEmployee);
                    passwordUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((EmployeeDAL)EmployeeDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public void Serialize()
        {
            try
            {
                EmployeeDALBase.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public void Deserialize()
        {
            try
            {
                EmployeeDALBase.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
