﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{/// <summary>
 /// Interface for ChequeBook Entity
 /// </summary>
    public interface IChequeBook
    {
        Guid ChequeBookId { get; set; }
        Guid AccountId { get; set; }
        string AccountNo { get; set; }
        double SeriesStart { get; set; }
        DateTime ChequeBookRequestDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        int NumberOfLeaves { get; set; }
        string ChequeBookStatus { get; set; }

    }

    /// <summary>
    /// Represents DebitCard
    /// </summary>
    public class ChequeBook : IChequeBook
    {/* Auto-Implemented Properties */

        [Required("ChequeBook ID can't be blank.")]
        public Guid ChequeBookId { get; set; }
       // [Required("Account ID can't be blank.")]
        public Guid AccountId { get; set; }
        [Required("Account number should not be null.")]
        [RegExp(@"^([1][0-9]{9})$", "Length of the AccountNumber should be 10")]
        public string AccountNo { get; set; }
        [Required("Series starting number should not be blank.")]
        [RegExp(@"^([0-9]{6})$", "Length of the series should be 6")]
        public double SeriesStart { get; set; }
        public DateTime ChequeBookRequestDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        
        public int NumberOfLeaves { get; set; }
        public string ChequeBookStatus { get; set; }
        public ChequeBook()
        {
            ChequeBookId = default(Guid);
            AccountId = default(Guid);
            AccountNo = null;
            SeriesStart = default(long);
            NumberOfLeaves = default(int);
            ChequeBookStatus = null;

        }

       
    }
}
