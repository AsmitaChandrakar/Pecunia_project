﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;

namespace Pecunia.Contracts.BLContracts
{
    public interface ICustomerBL : IDisposable
    {
        Task<bool> AddCustomerBL(Customer newCustomer);
        Task<List<Customer>> GetAllCustomersBL();
        Task<Customer> GetCustomerByCustomerNumberBL(string searchCustomerNumber);
        Task<List<Customer>> GetCustomersByNameBL(string CustomerName);
        Task<Customer> GetCustomerByEmailBL(string email);
        Task<Customer> GetCustomerByCustomerMobileBL(string mobile);
        Task<Customer> GetCustomerByCustomerAadharNumberBL(string aadhar);
        Task<Customer> GetCustomerByCustomerPANNumberBL(string pan);
        Task<bool> UpdateCustomerBL(Customer updateCustomer);

    }
}
