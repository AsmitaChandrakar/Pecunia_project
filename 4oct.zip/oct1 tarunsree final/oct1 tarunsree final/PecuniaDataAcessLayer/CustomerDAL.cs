﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using Pecunia.Helpers;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating ,searching Customers from Customers collection.
    /// </summary>
    public class CustomerDAL : CustomerDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Customer to Customers collection.
        /// </summary>
        /// <param name="newCustomer">Contains the Customer details to be added.</param>
        /// <returns>Determinates whether the new Customer is added.</returns>
        public override bool AddCustomerDAL(Customer newCustomer)
        {
            bool CustomerAdded = false;
            try
            {
                newCustomer.CustomerID = Guid.NewGuid();
                newCustomer.CreationDateTime = DateTime.Now;
                newCustomer.LastModifiedDateTime = DateTime.Now;
                CustomerList.Add(newCustomer);
                CustomerAdded = true;

                //if (GetAllCustomersDAL().Count == 0)
                //{
                //    newCustomer.CustomerNumber = CustomerConfiguration.baseCustomerNumber;
                //    //WriteLine(newCustomer.CustomerNumber);
                //}
                //else
                //{
                //    string nextCustomerNumber = (GetAllCustomersDAL().Max(temp => long.Parse(temp.CustomerNumber)) + 1).ToString();
                //    newCustomer.CustomerNumber = nextCustomerNumber;
                //}
            }
            catch (Exception)
            {
                throw;
            }
            return CustomerAdded;
        }

        /// <summary>
        /// Gets all Customers from the collection.
        /// </summary>
        /// <returns>Returns list of all Customers.</returns>
        public override List<Customer> GetAllCustomersDAL()
        {
            return CustomerList;
        }

        /// <summary>
        /// Gets Customer based on CustomerNumber.
        /// </summary>
        /// <param name="searchCustomerNumber">Represents CustomerNumber to search.</param>
        /// <returns>Returns Customer object.</returns>
        public override Customer GetCustomerByCustomerNumberDAL(string searchCustomerNumber)
        {
            Customer matchingCustomer = null;
            try
            {
                //Find Customer based on searchCustomerID
                matchingCustomer = CustomerList.Find(
                    (item) => { return item.CustomerNumber == searchCustomerNumber; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }

        /// <summary>
        /// Gets Customer based on CustomerName.
        /// </summary>
        /// <param name="CustomerName">Represents CustomerName to search.</param>
        /// <returns>Returns Customer object.</returns>
        public override List<Customer> GetCustomersByNameDAL(string CustomerName)
        {
            List<Customer> matchingCustomers = new List<Customer>();
            try
            {
                //Find All Customers based on CustomerName
                matchingCustomers = CustomerList.FindAll(
                    (item) => { return item.CustomerName.Equals(CustomerName, StringComparison.OrdinalIgnoreCase); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomers;
        }

        /// <summary>
        /// Gets Customer based on email.
        /// </summary>
        /// <param name="email">Represents Customer's Email Address.</param>
        /// <returns>Returns Customer object.</returns>
        public override Customer GetCustomerByEmailDAL(string email)
        {
            Customer matchingCustomer = null;
            try
            {
                //Find Customer based on Email 
                matchingCustomer = CustomerList.Find(
                    (item) => { return item.Email.Equals(email); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on Mobile number.
        /// </summary>
        /// <param name="mobile">Represents Customer's mobile number.</param>
        /// <returns>Returns Customer object.</returns>
        public override Customer GetCustomerByCustomerMobileDAL(string mobile)
        {
            Customer matchingCustomer = null;
            try
            {
                //Find Customer based on Mobile Number
                matchingCustomer = CustomerList.Find(
                    (item) => { return item.CustomerMobile.Equals(mobile); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on Aadhar Number.
        /// </summary>
        /// <param name="aadhar">Represents Customer's Aadhar Number.</param>
        /// <returns>Returns Customer object.</returns>
        public override Customer GetCustomerByCustomerAadharNumberDAL(string aadhar)
        {
            Customer matchingCustomer = null;
            try
            {
                //Find Customer based on Aadhar Number
                matchingCustomer = CustomerList.Find(
                    (item) => { return item.CustomerAadharNumber.Equals(aadhar); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on PAN number.
        /// </summary>
        /// <param name="pan">Represents Customer's PAN number.</param>
        /// <returns>Returns Customer object.</returns>
        public override Customer GetCustomerByCustomerPANNumberDAL(string pan)
        {
            Customer matchingCustomer = null;
            try
            {
                //Find Customer based on PAN number
                matchingCustomer = CustomerList.Find(
                    (item) => { return item.CustomerPANNumber.Equals(pan); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }




        /// <summary>
        /// Updates Customer based on CustomerNumber.
        /// </summary>
        /// <param name="updateCustomer">Represents Customer details including Customermobile, CustomerName etc.</param>
        /// <returns>Determinates whether the existing Customer is updated.</returns>
        public override bool UpdateCustomerDAL(Customer updateCustomer)
        {
            bool CustomerUpdated = false;
            try
            {
                //Find Customer based on CustomerID
                Customer matchingCustomer = GetCustomerByCustomerNumberDAL(updateCustomer.CustomerNumber);

                if (matchingCustomer != null)
                {
                    //Update Customer details
                    ReflectionHelpers.CopyProperties(updateCustomer, matchingCustomer, new List<string>() { "CustomerName", "CustomerMobile", "CustomerAddress", "Email" });
                    matchingCustomer.LastModifiedDateTime = DateTime.Now;

                    CustomerUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return CustomerUpdated;
        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}
