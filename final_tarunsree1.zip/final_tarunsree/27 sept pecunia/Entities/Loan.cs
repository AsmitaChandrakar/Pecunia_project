﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Helpers.ValidationAttribute;

namespace Pecunia.Entities
{
    public interface ILoan
    {
        String Customernumber { get; set; }
        Guid LoanID { get; set; }
        string LoanType { get; set; }
        Double AmtOfLoan { get; set; }
        string LoanStatus { get; set; }
        double Tenure { get; set; }
        double YearlyIncome { get; set; }
        double YearsOfService { get; set; }
        DateTime LoanApplyDate { get; set; }

    }
    public class Loan : ILoan
    {
        public string Customernumber { get; set; }

        // [Required("Distributor ID can't be blank.")]
        public Guid LoanID { get; set; }


        public string LoanType { get; set; }

        [Required("Loan Amount can't be blank.")]
        public double AmtOfLoan { get; set; }


        public string LoanStatus { get; set; }

        [Required("Loan Duration can't be blank.")]
        public double Tenure { get; set; }

        [Required("Loan Duration can't be blank.")]
        public double YearlyIncome { get; set; }

        [Required("Loan Duration can't be blank.")]
        public double YearsOfService { get; set; }

        [Required("Apply Date can't be blank.")]
        public DateTime LoanApplyDate { get; set; }

    }

    public class CarLoan : Loan
    {
        [Required("License can't be blank.")]
        public string License { get; set; }
    }

    public class HomeLoan : Loan
    {
        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }

    }

    public class PersonalLoan : Loan
    {
        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }

    }

    public class EducationLoan : Loan
    {
        [Required("Sponseror can't be blank.")]
        public string Sponseror { get; set; }

        [Required("CollegeName can't be blank.")]
        public string CollegeName { get; set; }

        [Required("Admission can't be blank.")]
        public string AdmissionID { get; set; }

        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }
    }


}
