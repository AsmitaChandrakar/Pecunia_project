﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using Pecunia.Exceptions;

namespace Pecunia.BusinessLayer
{
    public class TransactionsBL : BLBase<Transaction>, ITransactionsBL, IDisposable
    {
        TransactionDALBase TransactionsDAL;

        public TransactionsBL()
        {
            TransactionsDAL = new TransactionsDAL();
        }

        protected async override Task<bool> Validate(Transaction entityObject)
        {

            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);
            if (valid == false)
                throw new PecuniaException(sb.ToString());

            return valid;

        }

        public async Task<bool> AddTransactionBL(Transaction newTransaction)
        {
            bool EmployeeAdded = false;
            try
            {
                if (await Validate(newTransaction))
                {
                    await Task.Run(() =>
                    {
                        this.TransactionsDAL.AddTransactionDAL(newTransaction);
                        EmployeeAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return EmployeeAdded;
        }
        public async Task<List<Transaction>> GetAllTransactionsBL()
        {
            List<Transaction> TransactionList = null;
            try
            {
                await Task.Run(() =>
                {
                    TransactionList = TransactionsDAL.GetAllTransactionsDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return TransactionList;
        }

        public async Task<List<Transaction>> GetAllTransactionsByTransactionTypeBL(string transactionType)
        {
            List<Transaction> matchingTransaction = new List<Transaction>();
            try
            {
                await Task.Run(() =>
                {
                    matchingTransaction = TransactionsDAL.GetAllTransactionsByTransactionTypeDAL(transactionType);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransaction;
        }

        public async Task<List<Transaction>> GetAllTransactionsByAccountNumberBL(string accountNumber)
        {
            List<Transaction> matchingTransaction = new List<Transaction>();
            try
            {
                await Task.Run(() =>
                {
                    matchingTransaction = TransactionsDAL.GetAllTransactionsByAccountNumberDAL(accountNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransaction;
        }
        public async Task<List<Transaction>> GetAllTransactionsByTimeBL(DateTime TransactionsDateTime)
        {
            List<Transaction> matchingTransaction = new List<Transaction>();
            try
            {
                await Task.Run(() =>
                {
                    matchingTransaction = TransactionsDAL.GetAllTransactionsByTimeDAL(TransactionsDateTime);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransaction;
        }
        public void Dispose()
        {
            ((TransactionsDAL)TransactionsDAL).Dispose();
        }

        public void Serialize()
        {
            try
            {
                TransactionDALBase.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void Deserialize()
        {
            try
            {
                TransactionDALBase.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

    }

}
