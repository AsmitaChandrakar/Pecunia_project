﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Exceptions;
using Pecunia.Helpers;


namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting accounts from Accounts collection.
    /// </summary>
    public class RegularAccountBL : BLBase<RegularAccount>, IRegularAccountBL, IDisposable
    {
        //fields
        RegularAccountDALBase regaccountDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public RegularAccountBL()
        {
            this.regaccountDAL = new RegularAccountDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>

        protected async override Task<bool> Validate(RegularAccount entityObject)
        {

            //Create string builder
            StringBuilder sb = new StringBuilder();

            bool valid = await base.Validate(entityObject);

            //Branch should be in (Mumbai,Bengaluru,Delhi,Chennai) 
            if(!(entityObject.Branch.Equals("Mumbai", StringComparison.OrdinalIgnoreCase))&&!(entityObject.Branch.Equals("Bengaluru", StringComparison.OrdinalIgnoreCase))
                &&!(entityObject.Branch.Equals("Delhi", StringComparison.OrdinalIgnoreCase))&&!(entityObject.Branch.Equals("Chennai", StringComparison.OrdinalIgnoreCase)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Branch should be one among Mumbai, Chennai, Delhi or Bengaluru");
            }


            //The customer no must be valid
            if (entityObject.CustomerNo.Length != 6)
            {
                
                valid = false;
                sb.Append(Environment.NewLine + "Customer no entered is not valid");
            }


            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;

        }


        /// <summary>
        /// Adds new account to Accounts collection.
        /// </summary>
        /// <param name="newAccount">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> CreateAccountBL(RegularAccount newAccount)
        {
            bool AccountCreated = false;
            try
            {
                if (await Validate(newAccount))
                {
                    await Task.Run(() =>
                    {
                       
                        regaccountDAL.CreateAccountDAL(newAccount);

                        //Account No generator
                        if(regaccountDAL.GetAllAccountsDAL().Count == 0)
                        {
                            newAccount.AccountNo = Convert.ToString(AccountsConfiguration.baseAccountNo1);
                        }
                        else
                        {
                            int a = RegularAccountDALBase.regularAccountList.Count();
                            long nextAccountNo = AccountsConfiguration.baseAccountNo1 + a;
                            newAccount.AccountNo = nextAccountNo.ToString();

                        }


                        AccountCreated = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountCreated;
        }

        /// <summary>
        /// Gets all accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public async Task<List<RegularAccount>> GetAllAccountsBL()
        {
            List<RegularAccount> accountList = null;
            try
            {
                await Task.Run(() =>
                {
                    accountList = regaccountDAL.GetAllAccountsDAL();
                });

            }
            catch (Exception)
            {
                throw;
            }
            return accountList;
        }

        /// <summary>
        /// Gets account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of Account Class.</returns>
        public async Task<RegularAccount> GetAccountByAccountNoBL(string searchAccountNo)
        {
            RegularAccount searchAccount = null;
            try
            {
                await Task.Run(() =>
                {
                    searchAccount = regaccountDAL.GetAccountByAccountNoDAL(searchAccountNo);
                });

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;

        }


        /// <summary>
        /// Gets list of accounts based on CustomerNo
        /// </summary>
        /// <param name="searchCustomerNo">Contains the Customer No to search the accounts.</param>
        /// <returns>Returns the list of Account class objects where the Customer No matches.</returns>
        public async Task<List<RegularAccount>> GetAccountsByCustomerNoBL(string searchCustomerNo)
        {

            List<RegularAccount> AccountsByCustNo = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByCustNo = regaccountDAL.GetAccountsByCustomerNoDAL(searchCustomerNo);
                });


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;

        }


        /// <summary>
        /// Gets list of accounts based on Account Type
        /// </summary>
        /// <param name="searchAccountType">Contains the type of account(Savings or Current) to search the accounts.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public async Task<List<RegularAccount>> GetAccountsByTypeBL(string searchAccountType)
        {

            List<RegularAccount> AccountsByType = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByType = regaccountDAL.GetAccountsByTypeDAL(searchAccountType);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByType;

        }

        /// <summary>
        /// Gets list of accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public async Task<List<RegularAccount>> GetAccountsByBranchBL(string searchBranch)
        {

            List<RegularAccount> AccountsByBranch = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByBranch = regaccountDAL.GetAccountsByBranchDAL(searchBranch);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByBranch;

        }

        /// <summary>
        /// Gets list of accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of Regular Account class objects.</returns>
        public async Task<List<RegularAccount>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate)
        {

            List<RegularAccount> AccountsByDate = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByDate = regaccountDAL.GetAccountsByAccountOpeningDateDAL(startDate, endDate);
                });

            }

            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;

        }

        /// <summary>
        /// Gets Current Balance in the account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public async Task<double> GetBalanceBL(string accountNumber)
        {

            double balance = 0;
            try
            {
                await Task.Run(() =>
                {
                    balance = regaccountDAL.GetBalanceDAL(accountNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return balance;

        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public async Task<bool> UpdateBalanceBL(string accountNumber, double balance)
        {

            bool BalanceUpdated = false;

            try
            {
                if (await GetAccountByAccountNoBL(accountNumber) != null)
                {
                    regaccountDAL.UpdateBalanceDAL(accountNumber, balance);
                    BalanceUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of an account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public async Task<bool> UpdateBranchBL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;
            try
            {
                if((await GetAccountByAccountNoBL(accountNumber) != null) &&
                        ((branch.Equals("Mumbai", StringComparison.OrdinalIgnoreCase)) || (branch.Equals("Bengaluru", StringComparison.OrdinalIgnoreCase))
                || (branch.Equals("Delhi", StringComparison.OrdinalIgnoreCase)) || (branch.Equals("Chennai", StringComparison.OrdinalIgnoreCase))))
                
                    {
                    this.regaccountDAL.UpdateBranchDAL(accountNumber, branch);
                    AccountBranchUpdated = true;
                    Serialize();
                    }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountBranchUpdated;
        }

        /// <summary>
        /// Updates the account type from savings to current or vice-versa
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="accountType">Contains the new account type of the account.</param>
        /// <returns>Determines whether the account type is updated or not.</returns>
        public async Task<bool> UpdateAccountTypeBL(string accountNumber, string accountType)
        {
            bool AccountTypeUpdated = false;
            try
            {
                if ((await GetAccountByAccountNoBL(accountNumber) != null) && ((accountType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accountType.Equals("Current", StringComparison.OrdinalIgnoreCase))))
                {
                    regaccountDAL.UpdateAccountTypeDAL(accountNumber, accountType);
                    AccountTypeUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountTypeUpdated;
        }

        /// <summary>
        /// Deletes an existing account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public async Task<bool> DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                if (await GetAccountByAccountNoBL(deleteAccountNo) != null)
                {
                    this.regaccountDAL.DeleteAccountDAL(deleteAccountNo);
                    AccountDeleted = true;
                    Serialize();
                }
            }

            catch (Exception)
            {
                throw;
            }

            return AccountDeleted;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((RegularAccountDAL)regaccountDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                RegularAccountDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                RegularAccountDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}

