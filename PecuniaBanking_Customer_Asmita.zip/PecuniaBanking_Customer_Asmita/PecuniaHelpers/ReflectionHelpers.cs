﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.Pecunia.Helpers
{
    class ReflectionHelpers
    {
        //Help in cloning 1 object from one to another

    }
}
