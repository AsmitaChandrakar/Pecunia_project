﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.Pecunia.Entities;

namespace Capgemini.Pecunia.Contracts.BLContracts
{
    public interface ICustomerBL : IDisposable
    {
        Task<bool> AddCustomerBL(Customer newCustomer);
        Task<List<Customer>> GetAllCustomersBL();
        Task<Customer> GetCustomerByCustomerIDBL(Guid searchCustomerID);
        Task<List<Customer>> GetCustomersByNameBL(string CustomerName);
        Task<Customer> GetCustomerByEmailBL(string email);
        Task<bool> UpdateCustomerBL(Customer updateCustomer);
        
    }
}


