﻿using System;

namespace Entities
{
    internal class RequiredAttribute : Attribute
    {
    }
}