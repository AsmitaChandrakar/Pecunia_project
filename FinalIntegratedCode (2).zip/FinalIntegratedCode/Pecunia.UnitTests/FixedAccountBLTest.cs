﻿//Created by Akash Kumar Singh


using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using System.Collections.Generic;



namespace Pecunia.UnitTest
{
    [TestClass]
    public class FixedAccountBLTest
    {
        /// <summary>
        /// Creating valid fixed account
        /// </summary>
        [TestMethod]
        public async Task CreateValidFixedAccount()
        {
            //Arrange

            //Adding a customer
            Customer customer = new Customer
            {
                CustomerName = "Scottish",
                CustomerMobile = "9876043210",
                CustomerAddress = "ScZXCV254GV",
                Email = "scooott@gmail.com",
                CustomerAadharNumber = "825730998651",
                CustomerPANNumber = "BLKPC1977R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1997-02-22"),
                WorkExperience = 3.5,
                AnnualIncome = 234567
            };

            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            //Creating a new account
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Delhi", Tenure = 12, FDDeposit = 50000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Customer ID should be valid
        /// </summary>
        [TestMethod]
        public async Task CustomerIDshouldBeValid()
        {
            //Arrange

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = default(Guid), AccountType = "Fixed", Branch = "Mumbai", Tenure = 10, FDDeposit = 100000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Type can't be null
        /// </summary>
        [TestMethod]
        public async Task AccountTypeCanNotBeNull()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Dhiraj",
                CustomerMobile = "9828000011",
                CustomerAddress = "Bilaspur",
                Email = "dhiraj@gmail.com",
                CustomerAadharNumber = "888888589651",
                CustomerPANNumber = "MMQOP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1959-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = null, Branch = "mumbai", Tenure = 5, FDDeposit = 75000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Tenure can't be Invalid 
        /// </summary>
        [TestMethod]
        public async Task TenureCanNotBeInvalid()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Niraj",
                CustomerMobile = "9828001111",
                CustomerAddress = "Bilaspur",
                Email = "niraj@gmail.com",
                CustomerAadharNumber = "888888589622",
                CustomerPANNumber = "MMQOP1977Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1959-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "mumbai", Tenure = default(Double), FDDeposit = 75000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// FDDeposit Amount can't be invalid
        /// </summary>
        [TestMethod]
        public async Task FDDepositCanNotBeInvalid()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Shiraj",
                CustomerMobile = "9828503011",
                CustomerAddress = "Bilaspur",
                Email = "shiraj@gmail.com",
                CustomerAadharNumber = "888555589651",
                CustomerPANNumber = "MMQIP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1959-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = null, Branch = "mumbai", Tenure = 5, FDDeposit = default(Double) };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Account Branch can't be null
        /// </summary>
        [TestMethod]
        public async Task BranchCanNotBeNull()
        {


            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Deepak",
                CustomerMobile = "9828005555",
                CustomerAddress = "Bilaspur",
                Email = "deepak@gmail.com",
                CustomerAadharNumber = "111111589651",
                CustomerPANNumber = "BBQOP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1989-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = null, Tenure = 5, FDDeposit = 250000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Customer ID should not be new
        /// </summary>
        [TestMethod]
        public async Task CustomerIDShouldNotBeNew()
        {
            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = Guid.NewGuid(), AccountType = "Fixed", Branch = "Bengaluru", Tenure = 5, FDDeposit = 500000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Account Type should be valid
        /// </summary>
        [TestMethod]
        public async Task AccountTypeShouldBeValid()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Deepak",
                CustomerMobile = "9828005555",
                CustomerAddress = "Bilaspur",
                Email = "deepak@gmail.com",
                CustomerAadharNumber = "111111589651",
                CustomerPANNumber = "BBQOP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1989-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Salary", Branch = "Bengaluru", Tenure = 5, FDDeposit = 500000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru")
        /// </summary>
        [TestMethod]
        public async Task BranchShouldBeValid()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Ajay",
                CustomerMobile = "9827997234",
                CustomerAddress = "Raigarh",
                Email = "ajay@outlook.com",
                CustomerAadharNumber = "485632785124",
                CustomerPANNumber = "ADKPC1985W",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("199-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fix = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Kolkata", Tenure = 8, FDDeposit = 600000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fix);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// branch should be valid
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranch()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Ashish",
                CustomerMobile = "9827997111",
                CustomerAddress = "Raigarh",
                Email = "scotindia@gmail.com",
                CustomerAadharNumber = "825738259671",
                CustomerPANNumber = "ADEWC1985R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1995-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount()
            {
                CustomerID = customer.CustomerID,
                AccountType = "Fixed",
                Branch = "Mumbai",
                Tenure = 2,
                FDDeposit = 100000
            };

            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fixAccount1);
                FixedAccount fixAccount = new FixedAccount() { AccountID = fixAccount1.AccountID, AccountNo = fixAccount1.AccountNo, CustomerID = fixAccount1.CustomerID, AccountType = "Fixed", Branch = "Chennai", Tenure = 2, FDDeposit = 100000 };
                isUpdated = await fixBL.UpdateBranchBL(fixAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru") while updating the record
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranchError()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Aishwarya",
                CustomerMobile = "8227997680",
                CustomerAddress = "Raigarh",
                Email = "aish@gmail.com",
                CustomerAadharNumber = "825738288881",
                CustomerPANNumber = "ADEWC1981Q",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1992-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Bengaluru", Tenure = 6.5, FDDeposit = 8000000 };
            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fixAccount);
                FixedAccount fixAccount1 = new FixedAccount() { AccountID = fixAccount.AccountID, CustomerID = fixAccount.CustomerID, AccountType = "Fixed", Branch = "Shimla", Tenure = 6.5, FDDeposit = 8000000 };
                isUpdated = await fixBL.UpdateBranchBL(fixAccount1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account no should be valid
        /// </summary>
        [TestMethod]
        public async Task UpdateAccountnoShouldBeValid()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Vijay",
                CustomerMobile = "9827865111",
                CustomerAddress = "Raigarh",
                Email = "india@gmail.com",
                CustomerAadharNumber = "825738579671",
                CustomerPANNumber = "MMMWC1985R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1950-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount()
            {
                CustomerID = customer.CustomerID,
                AccountType = "Fixed",
                Branch = "Mumbai",
                Tenure = 3.5,
                FDDeposit = 600000
            };

            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fixAccount1);
                FixedAccount fixAccount = new FixedAccount() { AccountNo = "5687", CustomerID = fixAccount1.CustomerID, AccountType = "Fixed", Branch = "Chennai", Tenure = 3.5, FDDeposit = 600000 };
                isUpdated = await fixBL.UpdateBranchBL(fixAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }



        /// <summary>
        /// Delete Valid Account
        /// </summary>
        [TestMethod]
        public async Task DeleteValidAccount()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Sita",
                CustomerMobile = "9884565999",
                CustomerAddress = "Nagpur",
                Email = "nagesh@gmail.com",
                CustomerAadharNumber = "796538588881",
                CustomerPANNumber = "LLKKW7896R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1990-12-05"),
                WorkExperience = 3,
                AnnualIncome = 7000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Delhi", Tenure = 8, FDDeposit = 600000 };
            bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fixAccount);
                isDeleted = await fixBL.DeleteAccountBL(fixAccount.AccountNo);

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }


        /// <summary>
        /// Deleting an inalid Account
        /// </summary>
        [TestMethod]
        public async Task DeleteAccountNoShouldBeValid()
        {
            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            //FixedAccount fixAccount = new FixedAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Delhi" };
            //bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                //isAdded = await fixBL.CreateAccountBL(fixAccount);
                isDeleted = await fixBL.DeleteAccountBL("10006523");

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isDeleted, errorMessage);
            }
        }

        /// <summary>
        /// Search Account by Valid Account No
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByValidAccountNo()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Nisha",
                CustomerMobile = "9824565111",
                CustomerAddress = "Ambikapur",
                Email = "nishu@outlook.com",
                CustomerAadharNumber = "222268589651",
                CustomerPANNumber = "SSTTW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 7, FDDeposit = 1200000 };
            bool isAdded = false;
            bool isSearched = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(fixAccount);
                if (fixAccount.Equals(await fixBL.GetAccountByAccountNoBL(fixAccount.AccountNo)))
                {
                    isSearched = true;
                }


            }
            catch (Exception ex)
            {
                isSearched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Account number should be a valid account number
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByAccountNoError()
        {
            //Arrange //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Vimal",
                CustomerMobile = "8108888111",
                CustomerAddress = "Rampur",
                Email = "viji@outlook.com",
                CustomerAadharNumber = "111168589651",
                CustomerPANNumber = "MNBVW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1985-10-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount FixedAccount = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Bengaluru", Tenure = 8, FDDeposit = 600000 };
            bool isAdded = false;
            bool isSearched = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await fixBL.CreateAccountBL(FixedAccount);
                if (FixedAccount.Equals(await fixBL.GetAccountByAccountNoBL("2014785")))
                {
                    isSearched = true;
                }


            }
            catch (Exception ex)
            {
                isSearched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Search Account by Customer
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByValidCustomer()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Avi",
                CustomerMobile = "8104565111",
                CustomerAddress = "Ambikapur",
                Email = "aviji@outlook.com",
                CustomerAadharNumber = "845268589651",
                CustomerPANNumber = "MMQQW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Fixed",
                Branch = "Chennai",
                Tenure = 8,
                FDDeposit = 600000
            };
            FixedAccount fixAccount2 = new FixedAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Fixed",
                Branch = "Mumbai",
                Tenure = 4,
                FDDeposit = 500000
            };

            bool isAdded1 = false;
            bool isAdded2 = false;

            List<FixedAccount> result = new List<FixedAccount>();

            result.Add(fixAccount1);
            result.Add(fixAccount2);

            List<FixedAccount> isSearched = new List<FixedAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded1 = await fixBL.CreateAccountBL(fixAccount1);
                isAdded2 = await fixBL.CreateAccountBL(fixAccount2);

                isSearched = await fixBL.GetAccountsByCustomerNoBL(customer.CustomerID);
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Search Account by Invalid Customer 
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByCustomerError()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Avinash",
                CustomerMobile = "8100005111",
                CustomerAddress = "Ambikapur",
                Email = "avijirocks@outlook.com",
                CustomerAadharNumber = "222268580909",
                CustomerPANNumber = "MMOOW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Fixed",
                Branch = "Mumbai",
                Tenure = 6,
                FDDeposit = 900000
            };

            bool isAdded1 = false;

            List<FixedAccount> result = new List<FixedAccount>();

            result.Add(fixAccount1);

            List<FixedAccount> isSearched = new List<FixedAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded1 = await fixBL.CreateAccountBL(fixAccount1);
                isSearched = await fixBL.GetAccountsByCustomerNoBL(new Guid());
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.AreNotEqual(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);

            }
        }

        ///<summary>
        /// Search Account by Valid home branch
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByValidBranch()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Savita",
                CustomerMobile = "9824565444",
                CustomerAddress = "Ambikapur",
                Email = "nishusav@outlook.com",
                CustomerAadharNumber = "222268589561",
                CustomerPANNumber = "SSIIW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();


            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 4, FDDeposit = 500000 };
            bool isAdded1 = false;

            FixedAccount fixAccount2 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Bengaluru", Tenure = 6, FDDeposit = 850000 };
            bool isAdded2 = false;

            FixedAccount fixAccount3 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 7, FDDeposit = 1000000 };
            bool isAdded3 = false;

            string errorMessage = null;

            List<FixedAccount> result = new List<FixedAccount>();
            result.Add(fixAccount1);
            result.Add(fixAccount3);

            List<FixedAccount> isSearched = new List<FixedAccount>();
            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await fixBL.CreateAccountBL(fixAccount1);
                isAdded2 = await fixBL.CreateAccountBL(fixAccount2);
                isAdded3 = await fixBL.CreateAccountBL(fixAccount3);
                isSearched = await fixBL.GetAccountsByBranchBL("Mumbai");

            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(isSearched, result);
            }
        }

        /// <summary>
        /// Home branch should be valid
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByBranchError()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Savitri",
                CustomerMobile = "9824565333",
                CustomerAddress = "Ambikapur",
                Email = "sissy@outlook.com",
                CustomerAadharNumber = "666668589561",
                CustomerPANNumber = "SSIIO4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();

            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 4, FDDeposit = 500000 };
            bool isAdded1 = false;

            string errorMessage = null;

            List<FixedAccount> acc = new List<FixedAccount>();
            acc.Add(fixAccount1);

            List<FixedAccount> result = new List<FixedAccount>();

            List<FixedAccount> isSearched = new List<FixedAccount>();


            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await fixBL.CreateAccountBL(fixAccount1);
                isSearched = await fixBL.GetAccountsByBranchBL("Kolkata");

            }
            catch (Exception ex)
            {
                //isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result, isSearched);
            }
        }


        /// <summary>
        /// Search Account by Account Opening Date
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByAccountOpeningDate()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Mrinal",
                CustomerMobile = "9800565444",
                CustomerAddress = "Ambikapur",
                Email = "mrinal@outlook.com",
                CustomerAadharNumber = "220068589561",
                CustomerPANNumber = "SSIIQ1086R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();


            //Arrange
            FixedAccountBL fixBL = new FixedAccountBL();
            FixedAccount fixAccount1 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 5, FDDeposit = 850000 };
            bool isAdded1 = false;

            FixedAccount fixAccount2 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Bengaluru", Tenure = 4, FDDeposit = 500000 };
            bool isAdded2 = false;

            FixedAccount fixAccount3 = new FixedAccount() { CustomerID = customer.CustomerID, AccountType = "Fixed", Branch = "Mumbai", Tenure = 6, FDDeposit = 300000 };
            bool isAdded3 = false;

            string errorMessage = null;

            List<FixedAccount> result = new List<FixedAccount>();
            result.Add(fixAccount1);
            result.Add(fixAccount2);
            result.Add(fixAccount3);

            List<FixedAccount> isSearched = new List<FixedAccount>();
            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await fixBL.CreateAccountBL(fixAccount1);
                isAdded2 = await fixBL.CreateAccountBL(fixAccount2);
                isAdded3 = await fixBL.CreateAccountBL(fixAccount3);
                isSearched = await fixBL.GetAccountsByAccountOpeningDateBL(Convert.ToDateTime("2019/10/07"), Convert.ToDateTime("2019/10/08"));

            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(isSearched, result);
            }
        }

    }
}




