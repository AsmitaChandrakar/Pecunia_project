﻿using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.BusinessLayer;
using Pecunia.Entities;
using PecuniaHelpers;


namespace Pecunia.UnitTest
{/// <summary>
/// Class For Testing
/// </summary>
    [TestClass]
    public class LoanBLTest
    {
        /// <summary>
        /// Unit Test To Add Valid Customer
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task AddValidCustomer()
        {
            //Arrange
            CustomerBL customerBL = new CustomerBL();
            Customer customer = new Customer() { CustomerName = "Shobhit", AnnualIncome = 50000, Email = "shob@gmail.com", WorkExperience = 5, CustomerMobile = "9425567172", CustomerAadharNumber = "123456789098", CustomerPANNumber = "AXHAT1234A", CustomerAddress = "ASDFGHJ", CustomerDOB = DateTime.Parse("1997/05/01"), CustomerGender = PecuniaHelpers.Gender.Male };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await customerBL.AddCustomerBL(customer);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Add Valid Car Loan
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task AddValidCarLoan()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, License = "AX1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test of Car Loan details Customer Number cannot be Null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task CarLoanCustomerNumberCannotBeNull()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = null, AmtOfLoan = 10000, Tenure = 5, License = "AX1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test Car Loan details License Number cannot be Null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task CarLoanLicenseCannotBeNull()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, License = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test Car Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task LoanAmtCannotBe0()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", AmtOfLoan = 0, Tenure = 5, License = "AX1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test Car Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task LoanDurationCannotBe0()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 0, License = "AX1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test Car Loan Invalid License Regex 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task LicenseRegEX()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 10, License = "A1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.AddCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Update Valid Car Loan details 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateValideValues()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "CL1000000001", AmtOfLoan = 1000, Tenure = 10, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///  Unit Test to Update Car Loan Customer Number cannot be Null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateCustomerNumberNull()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = null, LoanNumber = "CL1000000001", AmtOfLoan = 1000, Tenure = 10, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Update Loan Number cannot be Null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateLoanNumberNull()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = null, AmtOfLoan = 1000, Tenure = 10, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update  Car Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateLoanAmountValue0()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "CL1000000001", AmtOfLoan = 0, Tenure = 10, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Car Loan Duration cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateLoanDurationValue0()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "CL1000000001", AmtOfLoan = 1000, Tenure = 0, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Update Car Loan License cannot be Null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateLicenseNull()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "CL1000000001", AmtOfLoan = 1000, Tenure = 10, License = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Car Loan Invalid Loan Number 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateInValidLoanNumber()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "L1000000001", AmtOfLoan = 1000, Tenure = 10, License = "AZ1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Car Loan Invalid License Regex 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task UpdateLicenseRegexInvalid()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();
            CarLoan carloan = new CarLoan() { CustomerNumber = "100001", LoanNumber = "CL1000000001", AmtOfLoan = 1000, Tenure = 10, License = "A1220991234567" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.UpdateCarLoanBL(carloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Delete Car Loan but invalid Loan Number  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task DeleteLoanInvalidLoanNumber()
        {
            //Arrange
            CarLoanBL carloanBL = new CarLoanBL();

            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await carloanBL.DeleteCarLoanBL("L1000000001");
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Home Loan  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task AddValidHomeLoan()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan HomeLoan = new HomeLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.AddHomeLoanBL(HomeLoan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Home Loan but Customer Number cannot be Null  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanCustomerNumberCannotBeNull()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = null, AmtOfLoan = 10000, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.AddHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Home Loan but Loan Amount cannot be 0  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanAmountCannotBe0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", AmtOfLoan = 0, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.AddHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Home Loan but Loan Duration Cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanDurationCannotBe0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 0, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.AddHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Home Loan but Collateral Cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanCollateralCannotBe0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 10, Collateral = 0 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.AddHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Valid Loan Details 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateValideValues()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = "HL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 10000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Customer Number cannot be Null  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateCustomerNumberNull()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = null, LoanNumber = "HL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 10000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Loan Number cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateLoanNumberNull()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = null, AmtOfLoan = 1000, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateLoanAmountValue0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan Homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = "HL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(Homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateLoanDurationValue0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = "HL1000000001", AmtOfLoan = 1000, Tenure = 0, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Collateral cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateCollateral0()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = "HL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 0 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Home Loan but Loan Number cannot be Invalid 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanUpdateInValidLoanNumber()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();
            HomeLoan homeloan = new HomeLoan() { CustomerNumber = "100001", LoanNumber = "L1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.UpdateHomeLoanBL(homeloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Delete Home Loan but Loan Number cannot be invalid 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task HomeLoanDeleteLoanInvalidLoanNumber()
        {
            //Arrange
            HomeLoanBL homeloanBL = new HomeLoanBL();

            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await homeloanBL.DeleteHomeLoanBL("L1000000001");
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Add Personal Loan 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task AddValidPersonalLoan()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan PersonalLoan = new PersonalLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.AddPersonalLoanBL(PersonalLoan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Customer Number cannot be null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanCustomerNumberCannotBeNull()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = null, AmtOfLoan = 10000, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.AddPersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanAmtCannotBe0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", AmtOfLoan = 0, Tenure = 5, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.AddPersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanDurationCannotBe0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 0, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.AddPersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Collateral cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanCollateralCannotBe0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", AmtOfLoan = 1000, Tenure = 10, Collateral = 0 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.AddPersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateValideValues()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = "PL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 10000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to update Personal Loan but Customr Number cannot be null
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateCustomerNumberNull()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = null, LoanNumber = "PL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 10000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan but Loan Number cannot be null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateLoanNumberNull()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = null, AmtOfLoan = 1000, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan but Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateLoanAmountValue0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = "PL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan but Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateLoanDurationValue0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = "PL1000000001", AmtOfLoan = 1000, Tenure = 0, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan but Collateral cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateCollateral0()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = "PL1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 0 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to update Personal Loan but Loan Number cannot be invalid 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanUpdateInValidLoanNumber()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();
            PersonalLoan Personalloan = new PersonalLoan() { CustomerNumber = "100001", LoanNumber = "L1000000001", AmtOfLoan = 1000, Tenure = 10, Collateral = 1000 };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.UpdatePersonalLoanBL(Personalloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to delete Personal Loan but Loan Number cannot be invalid 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task PersonalLoanDeleteLoanInvalidLoanNumber()
        {
            //Arrange
            PersonalLoanBL PersonalloanBL = new PersonalLoanBL();

            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await PersonalloanBL.DeletePersonalLoanBL("L1000000001");
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Unit Test to Add Education Loan
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task AddValidEducationLoan()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Customr Number cannot be null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanCustomerNumberNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = null, AmtOfLoan = 10000, Tenure = 5, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanLoanAmt0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 0, Tenure = 5, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanDuration0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 0, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Collateral cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanCollateral0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 0, CollegeName = "NIT", AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but College Name cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanCollegeNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000, CollegeName = null, AdmissionID = "101", Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Admission ID cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanAdmissionIdNuull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000, CollegeName = "NIT", AdmissionID = null, Sponseror = "Self" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Add Personal Loan but Sponseror cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanSponseror()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", AmtOfLoan = 10000, Tenure = 5, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdate()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 20000, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Customer Number cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateCustomeNumberNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = null, LoanNumber = "EL1000000001", AmtOfLoan = 20000, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Loan Number cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateLoanNumberNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = null, AmtOfLoan = 20000, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Invalid Loan Number  
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateInvalidLoanNumberNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "L1000000001", AmtOfLoan = 20000, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Loan Amount cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateAmtofLoan0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Loan Duration cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateDurationofLoan0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 100, Tenure = 0, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Collateral cannot be 0 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateCollateralofLoan0()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 0, CollegeName = "NIT", AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but College Name cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateCollegeNameNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000, CollegeName = null, AdmissionID = "101", Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Admission ID cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateAdmissionIDNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = null, Sponseror = "SELF" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to Update Personal Loan but Sponseror cannot be Null 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanUpdateSponserorNull()
        {
            //Arrange
            EducationLoanBL eduloanBL = new EducationLoanBL();
            EducationLoan eduloan = new EducationLoan() { CustomerNumber = "100001", LoanNumber = "EL1000000001", AmtOfLoan = 0, Tenure = 10, Collateral = 1000, CollegeName = "NIT", AdmissionID = "101", Sponseror = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await eduloanBL.UpdateEducationLoanBL(eduloan);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Unit Test to delete Education Loan but Loan Number cannot be invalid 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public async Task EducationLoanDeleteLoanInvalidLoanNumber()
        {
            //Arrange
            EducationLoanBL EducationloanBL = new EducationLoanBL();

            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await EducationloanBL.DeleteEducationLoanBL("L1000000001");
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }
}

