﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.Entities;
using Pecunia.BusinessLayer;

namespace Pecunia.UnitTest
{

    [TestClass]
    public class CreditCardBLTest
    {
        [TestMethod]
        public async Task AddValidCreditCard()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Scott", CardType = "Infinia", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Name on credit card can't be null
        /// </summary>
        [TestMethod]
        public async Task NameOnCreditCardCanNotBeNull()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = null, CardType = "Infinia", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// CreditCard type can't be null
        /// </summary>
        [TestMethod]
        public async Task CreditCardTypeCanNotBeNull()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Tarun", CardType = null, CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// CreditCard Status can't be null
        /// </summary>
        [TestMethod]
        public async Task CreditCardStatusCanNotBeNull()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "John", CardType = "Infinia", CardStatus = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Name on Credit card should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task NameOnCreditCardShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "J", CardType = "Infinia", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// CreditCard type should be valid
        /// </summary>
        [TestMethod]
        public async Task CreditCardTypeShouldBeValid()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Asmitha", CardType = "Random", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// CreditCard status should be valid
        /// </summary>
        [TestMethod]
        public async Task CreditCardStatusShouldBeValid()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Asmitha", CardType = "Infinia", CardStatus = "Not active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        ///Update debit card status
        /// </summary>
        [TestMethod]
        public async Task UpdateCreditCardStatus()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            bool isAdded = false;

            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Tarunsree", CardType = "Infinia", CardStatus = "Active" };
            isAdded = await creditCardBL.AddCreditCardBL(creditCard);

            bool isUpdated = false;
            string errorMessage = null;
            //Act
            try
            {

                CreditCard creditCard1 = new CreditCard() { CreditCardID = creditCard.CreditCardID, CardNumber = creditCard.CardNumber, CustomerNameAsPerCard = "Tarunsree", CardType = "Infinia", CardStatus = "Active", ExpiryMMYYYY = "10/24", CardIssueDate = creditCard.CardIssueDate, LastModifiedDate = creditCard.LastModifiedDate };
                isUpdated = await creditCardBL.UpdateCreditCardStatusBL(creditCard1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }
        /// <summary>
        ///
        /// </summary>
        [TestMethod]
        public async Task UpdateCreditCardStatusError()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            bool isAdded = false;

            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "Tarunsree", CardType = "Infinia", CardStatus = "Active" };
            isAdded = await creditCardBL.AddCreditCardBL(creditCard);

            bool isUpdated = true;
            string errorMessage = null;
            //Act
            try
            {

                CreditCard creditCard1 = new CreditCard() { CreditCardID = creditCard.CreditCardID, CardNumber = "000000000000", CustomerNameAsPerCard = "Tarunsree", CardType = "Infinia", CardStatus = "Active", ExpiryMMYYYY = "10/24" };
                isUpdated = await creditCardBL.UpdateCreditCardStatusBL(creditCard1);
            }
            catch (Exception ex)
            {
                isUpdated = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }
        /// <summary>
        /// Get CreditCard if Credit Card number is valid
        /// </summary>
        [TestMethod]
        public async Task ValidCreditCardByCardNumber()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "John", CardType = "Infinia", CardStatus = "Active" };
            await creditCardBL.AddCreditCardBL(creditCard);
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                if (creditCard.Equals(await creditCardBL.GetCreditCardByCreditCardNumberBL(creditCard.CardNumber)))
                { isAdded = true; }
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// Show error if Credit Card number is invalid
        /// </summary>
        [TestMethod]
        public async Task InValidCreditCardByCardNumber()
        {
            //Arrange
            CreditCardBL creditCardBL = new CreditCardBL();
            bool isAdded = false;
            CreditCard creditCard = new CreditCard() { CustomerNameAsPerCard = "John", CardType = "Infinia", CardStatus = "Active" };
            isAdded = await creditCardBL.AddCreditCardBL(creditCard);
            string cardNumber = "000000000000";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                if ((creditCard = (await creditCardBL.GetCreditCardByCreditCardNumberBL(cardNumber))) == null)
                { isValid = false; }
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }

    }
}
