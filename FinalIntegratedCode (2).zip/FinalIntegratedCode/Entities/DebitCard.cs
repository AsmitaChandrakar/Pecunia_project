﻿using Pecunia.Helpers.ValidationAttribute;
using System;


namespace Pecunia.Entities
{
    /// <summary>
    /// Interface for DebitCard Entity
    /// </summary>
    public interface IDebitCard
    {
        Guid DebitCardID { get; set; }
        Guid AccountID { get; set; }
        string CustomerNameAsPerCard { get; set; }
        string CardNumber { get; set; }
        DateTime CardIssueDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        string ExpiryMMYYYY { get; set; }
        string CardType { get; set; }
        string CardStatus { get; set; }

    }

    /// <summary>
    /// Represents DebitCard
    /// </summary>
    public class DebitCard : IDebitCard
    {/* Auto-Implemented Properties */

        [Required("DebitCard ID can't be blank.")]
        public Guid DebitCardID { get; set; }
        public Guid AccountID { get; set; }
        [Required("Customer Name can't be blank.")]
        [RegExp(@"^(\w{2,40})$", "Customer Name should contain only 2 to 40 characters.")]
        public string CustomerNameAsPerCard { get; set; }
        public string CardNumber { get; set; }
        public DateTime CardIssueDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string ExpiryMMYYYY { get; set; }
        [Required("Card type can't be blank.")]
        public string CardType { get; set; }
        [Required("Card status can't be blank.")]
        public string CardStatus { get; set; }

        public DebitCard()
        {
            DebitCardID = default(Guid);
            AccountID = default(Guid);
            CustomerNameAsPerCard = null;
            CardNumber = null;

            CardType = null;
            CardStatus = null;
        }

    }
}