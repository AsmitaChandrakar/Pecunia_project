﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Helpers.ValidationAttribute;

namespace Pecunia.Entities
{
    /// <summary>
    /// Common Entities Interface
    /// </summary>
    public interface ILoan
    {
        String CustomerNumber { get; set; }
        String LoanNumber { get; set; }
        Guid LoanID { get; set; }
        string LoanType { get; set; }
        Double AmtOfLoan { get; set; }
        string LoanStatus { get; set; }
        double Tenure { get; set; }
        DateTime LoanApplyDate { get; set; }

    }
    /// <summary>
    /// Class Loan
    /// </summary>
    public class Loan : ILoan
    {

        public string LoanNumber { get; set; }

        [Required("Customer Number ID can't be blank.")]
        public string CustomerNumber { get; set; }

        [Required("Loan ID can't be blank.")]
        public Guid LoanID { get; set; }


        public string LoanType { get; set; }

        [Required("Loan Amount can't be blank.")]
        public double AmtOfLoan { get; set; }

        public string LoanStatus { get; set; }

        [Required("Loan Duration can't be blank.")]
        public double Tenure { get; set; }

        [Required("Apply Date can't be blank.")]
        public DateTime LoanApplyDate { get; set; }

    }

    /// <summary>
    /// Car Loan
    /// </summary>
    public class CarLoan : Loan
    {
        [Required("License can't be blank.")]
        [RegExp(@"^(?<intro>[A-Z]{2})(?<numeric>\d{2})(?<year>\d{4})(?<tail>\d{7})$", "Customer Name should contain only 2 to 40 characters.")]
        public string License { get; set; }
    }

    /// <summary>
    /// Home Loan
    /// </summary>
    public class HomeLoan : Loan
    {
        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }

    }

    /// <summary>
    /// Personal Class
    /// </summary>
    public class PersonalLoan : Loan
    {
        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }

    }

    /// <summary>
    /// Education Loan
    /// </summary>
    public class EducationLoan : Loan
    {
        [Required("Sponseror can't be blank.")]
        public string Sponseror { get; set; }

        [Required("CollegeName can't be blank.")]
        public string CollegeName { get; set; }

        [Required("Admission can't be blank.")]
        public string AdmissionID { get; set; }

        [Required("Collateral can't be blank.")]
        public double Collateral { get; set; }
    }


}