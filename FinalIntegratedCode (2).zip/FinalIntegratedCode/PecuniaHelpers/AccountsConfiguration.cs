﻿//Created by Akash Kumar Singh


namespace Pecunia.Helpers
{
    /// <summary>
    /// Assigning starting and default value to accountno 
    /// </summary>
    public class AccountsConfiguration
    {
        public static long baseAccountNo1 = 1000000000;
        public static long baseAccountNo2 = 2000000000;
        public static double interest = 3.5;
        public static double minbal = 500;
    }
}
