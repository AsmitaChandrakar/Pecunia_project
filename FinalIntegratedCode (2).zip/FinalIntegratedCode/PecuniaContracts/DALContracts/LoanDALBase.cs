﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Newtonsoft.Json;



namespace Pecunia.Contracts.DALContracts
{

    /// <summary>
    /// Abstract class for Car Loan DAL class
    /// </summary>
    public abstract class CarLoanDALBase
    {
        //List of Car Loan
        protected static List<CarLoan> CarLoanList = new List<CarLoan>();

        //File Name
        private static string CarFileName = "CarLoan.json";

        //Methods for CRUD operations
        public abstract bool AddCarLoanDAL(CarLoan NewCarloan);
        public abstract List<CarLoan> GetAllCarLoanDAL();
        public abstract CarLoan GetCarLoanByLoanNumberDAL(string searchloannumber);
        public abstract List<CarLoan> GetCarLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateCarLoanDAL(CarLoan updatedloan);
        public abstract bool DeleteCarLoanDAL(string searchloannumber);
        public abstract CarLoan GetCarLoanByCustomerDAL(string searchloannumber);
        public abstract CarLoan GetCarLoanByLicenseDAL(string searchlicense);
        public abstract bool GetCarEligibility(string searchloannumber);

        /// <summary>
        /// To Serialise Car Loan Details in JSON Format
        /// </summary>
        static public void CarSerialize()
        {
            string serializedJson = JsonConvert.SerializeObject(CarLoanList);
            using (StreamWriter streamWriter = new StreamWriter(CarFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }

        /// <summary>
        /// To Deserialise from the file and store in Car Loan list.
        /// </summary>
        static public void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(CarFileName))
                File.Create(CarFileName).Close();

            using (StreamReader streamReader = new StreamReader(CarFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var CarListFromFile = JsonConvert.DeserializeObject<List<CarLoan>>(fileContent);
                if (CarListFromFile != null)
                {
                    CarLoanList = CarListFromFile;
                }
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public CarLoanDALBase()
        {
            // Deserialize();
        }
    }



    /// <summary>
    /// Abstract class for Home Loan DAL class
    /// </summary>
    public abstract class HomeLoanDALBase
    {
        //List of all Home Loan
        protected static List<HomeLoan> HomeLoanList = new List<HomeLoan>();
        //File Name
        private static string HomeFileName = "HomeLoan.json";

        //Methods for CRUD operations
        public abstract bool AddHomeLoanDAL(HomeLoan NewHomeloan);
        public abstract List<HomeLoan> GetAllHomeLoanDAL();
        public abstract HomeLoan GetHomeLoanByLoanNumberDAL(string loannumber);
        public abstract List<HomeLoan> GetHomeLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateHomeLoanDAL(HomeLoan updatedloan);
        public abstract bool DeleteHomeLoanDAL(string searchloannumber);
        public abstract HomeLoan GetHomeLoanByCustomerDAL(string searchloannumber);
        public abstract bool GetHomeEligibility(string searchloannumber);

        /// <summary>
        /// To Serialise Home Loan Details in JSON Format
        /// </summary>
        public void Homeserialize()
        {
            string serializedJson = JsonConvert.SerializeObject(HomeLoanList);
            using (StreamWriter streamWriter = new StreamWriter(HomeFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// To deserialize from file and store in Home Loan list
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(HomeFileName))
                File.Create(HomeFileName).Close();

            using (StreamReader streamReader = new StreamReader(HomeFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var HomeListFromFile = JsonConvert.DeserializeObject<List<HomeLoan>>(fileContent);
                if (HomeListFromFile != null)
                {
                    HomeLoanList = HomeListFromFile;
                }
            }
        }

        /// <summary>
        ///Class Constructor 
        /// </summary>
        public HomeLoanDALBase()
        {
            // Deserialize();
        }
    }


    /// <summary>
    /// Abstract class for Education Loan DAL class
    /// </summary>
    public abstract class EducationLoanDALBase
    {
        //List of all Education Loan
        protected static List<EducationLoan> EducationLoanList = new List<EducationLoan>();
        //File Name
        private static string EducationFileName = "EducationLoan.json";

        //Methods for CRUD operations
        public abstract bool AddEducationLoanDAL(EducationLoan NewEducationloan);
        public abstract List<EducationLoan> GetAllEducationLoanDAL();
        public abstract EducationLoan GetEducationLoanByLoanNumberDAL(string loannumber);
        public abstract List<EducationLoan> GetEducationLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateEducationLoanDAL(EducationLoan updatedloan);
        public abstract bool DeleteEducationLoanDAL(string loannumber);
        public abstract EducationLoan GetEduLoanByCustomerDAL(string searchloannumber);
        public abstract bool GetEducationEligibility(string searchloannumber);

        /// <summary>
        /// To Serialise Education Loan Details in JSON Format
        /// </summary>
        public void Educationserialize()
        {
            string serializedJson = JsonConvert.SerializeObject(EducationLoanList);
            using (StreamWriter streamWriter = new StreamWriter(EducationFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// To deserialize from file and store in Education Loan list 
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(EducationFileName))
                File.Create(EducationFileName).Close();

            using (StreamReader streamReader = new StreamReader(EducationFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var EduListFromFile = JsonConvert.DeserializeObject<List<EducationLoan>>(fileContent);
                if (EduListFromFile != null)
                {
                    EducationLoanList = EduListFromFile;
                }
            }
        }

        /// <summary>
        ///Class Constructor 
        /// </summary>
        public EducationLoanDALBase()
        {
            //       Deserialize();
        }

    }


    /// <summary>
    /// Abstract class for Personal Loan DAL class
    /// </summary>
    public abstract class PersonalLoanDALBase
    {
        //List of all Personal Loan
        protected static List<PersonalLoan> PersonalLoanList = new List<PersonalLoan>();
        //File Name
        private static string PersonalFileName = "PersonalLoan.json";

        //Methods for CRUD operations
        public abstract bool AddPersonalLoanDAL(PersonalLoan NewCarloan);
        public abstract List<PersonalLoan> GetAllPersonalLoanDAL();
        public abstract PersonalLoan GetPersonalLoanByLoanNumberDAL(string loannumber);
        public abstract List<PersonalLoan> GetPersonalLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdatePersonalLoanDAL(PersonalLoan updatedloan);
        public abstract bool DeletePersonalLoanDAL(string loannumber);
        public abstract PersonalLoan GetPersonalLoanByCustomerDAL(string searchloannumber);
        public abstract bool GetPersonalEligibility(string searchloannumber);

        /// <summary>
        /// To Serialize Education Loan Details in JSON format
        /// </summary>
        public bool Personalserialize()
        {
            bool serialized = false;
            string serializedJson = JsonConvert.SerializeObject(PersonalLoanList);
            using (StreamWriter streamWriter = new StreamWriter(PersonalFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
                serialized = true;
            }
            return serialized;
        }

        /// <summary>
        /// To Deserialize from file and store into list
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(PersonalFileName))
                File.Create(PersonalFileName).Close();

            using (StreamReader streamReader = new StreamReader(PersonalFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var PerListFromFile = JsonConvert.DeserializeObject<List<PersonalLoan>>(fileContent);
                if (PerListFromFile != null)
                {
                    PersonalLoanList = PerListFromFile;
                }
            }
        }

        /// <summary>
        /// Class Constructor
        /// </summary>
        public PersonalLoanDALBase()
        {
            //     Deserialize();
        }


    }
}
