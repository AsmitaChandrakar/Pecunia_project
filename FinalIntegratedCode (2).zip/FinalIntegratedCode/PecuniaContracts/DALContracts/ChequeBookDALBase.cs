﻿using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base class for ChequeBookDAL class
    /// </summary>
    public abstract class ChequeBookDALBase
    {
        protected static List<ChequeBook> chequeBooksList = new List<ChequeBook>();

        private static string fileName = "chequeBooks.json";

        //Methods for CRUD operations
        public abstract bool AddChequeBookDAL(ChequeBook chequeBook);
        public abstract List<ChequeBook> GetChequeBookListDAL();
        public abstract bool UpdateChequeBookStatusDAL(ChequeBook chequeBook);
        public abstract List<ChequeBook> GetChequeBooksByAccountIDDAL(Guid accountID);
        public abstract List<ChequeBook> GetChequeBooksByAccountIDAndStatusDAL(Guid accountID, string status);
        public abstract ChequeBook GetChequeBookBySeriesStartDAL(double seriesStart);
        public abstract ChequeBook GetChequeBookByChequeBookIDDAL(Guid chequeBookID);

        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(chequeBooksList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }


        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var chequeBooksListFromFile = JsonConvert.DeserializeObject<List<ChequeBook>>(fileContent);
                if (chequeBooksListFromFile != null)
                {
                    chequeBooksList = chequeBooksListFromFile;
                }
            }
        }
        /// <summary>
        /// Static Constructor.
        /// </summary>
        public ChequeBookDALBase()
        {
            Deserialize();
        }

    }
}
