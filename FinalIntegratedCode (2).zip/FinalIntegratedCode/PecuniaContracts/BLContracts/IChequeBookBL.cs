﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface iChequeBookBL : IDisposable
    {

        Task<bool> AddChequeBookBL(ChequeBook chequeBook);
        Task<List<ChequeBook>> GetAllChequeBooksBL();
        Task<bool> UpdateChequeBookStatusBL(ChequeBook chequeBook);
        Task<List<ChequeBook>> GetChequeBooksByAccountIDBL(Guid accountID);
        Task<List<ChequeBook>> GetChequeBooksByAccountIDAndStatusBL(Guid accountID, string status);
        Task<ChequeBook> GetChequeBookBySeriesStartBL(double seriesStart);
        Task<ChequeBook> GetChequeBookByChequeBookIDBL(Guid chequeBookID);


    }
}
