﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;

namespace Pecunia.Contracts.BLContracts
{
    /// <summary>
    /// Interface for CarLoan
    /// </summary>
    public interface ICarLoanBL : IDisposable
    {
        Task<bool> AddCarLoanBL(CarLoan newloan);
        Task<List<CarLoan>> GetAllCarLoanBL();
        Task<CarLoan> GetCarLoanByLoanNumberBL(string loannumber);
        Task<bool> CarLoanEligibilityBL(string loannumber);
        Task<List<CarLoan>> GetCarLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateCarLoanBL(CarLoan updatedloan);
        Task<bool> DeleteCarLoanBL(string loannumber);
    }

    /// <summary>
    ///Interface for Home Loan 
    /// </summary>
    public interface IHomeLoanBL : IDisposable
    {
        Task<bool> AddHomeLoanBL(HomeLoan newloan);
        Task<List<HomeLoan>> GetAllHomeLoanBL();
        Task<HomeLoan> GetHomeLoanByLoanNumberBL(string loannumber);
        Task<bool> HomeLoanEligibilityBL(string loannumber);
        Task<List<HomeLoan>> GetHomeLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateHomeLoanBL(HomeLoan updatedloan);
        Task<bool> DeleteHomeLoanBL(string loannumber);

    }

    /// <summary>
    ///Interface for Personal Loan 
    /// </summary>
    public interface IPersonalLoanBL : IDisposable
    {
        Task<bool> AddPersonalLoanBL(PersonalLoan newloan);
        Task<List<PersonalLoan>> GetAllPersonalLoanBL();
        Task<PersonalLoan> GetPersonalLoanByLoanNumberBL(string loannumber);
        Task<bool> PersonalLoanEligibilityBL(string loannumber);
        Task<List<PersonalLoan>> GetPersonalLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdatePersonalLoanBL(PersonalLoan updatedloan);
        Task<bool> DeletePersonalLoanBL(string loanNumber);

    }

    /// <summary>
    /// Interface for Education Loan
    /// </summary>
    public interface IEducationLoanBL : IDisposable
    {
        Task<bool> AddEducationLoanBL(EducationLoan newloan);
        Task<List<EducationLoan>> GetAllEducationLoanBL();
        Task<EducationLoan> GetEducationLoanByLoanNumberBL(string loanNumber);
        Task<bool> EducationLoanEligibilityBL(string loannumber);
        Task<List<EducationLoan>> GetEducationLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateEducationLoanBL(EducationLoan updatedloan);
        Task<bool> DeleteEducationLoanBL(string deleteLoanNumber);

    }

}
