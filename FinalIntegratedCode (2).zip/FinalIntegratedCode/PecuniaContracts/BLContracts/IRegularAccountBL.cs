﻿//Created by Akash Kumar Singh


using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    
        public interface IRegularAccountBL : IDisposable
        {
            Task<bool> CreateAccountBL(RegularAccount newAccount);
            Task<List<RegularAccount>> GetAllAccountsBL();
            Task<RegularAccount> GetAccountByAccountNoBL(string searchAccountNo);
            Task<List<RegularAccount>> GetAccountsByCustomerNoBL(Guid searchCustomerID);
            Task<List<RegularAccount>> GetAccountsByTypeBL(string searchAccountType);
            Task<List<RegularAccount>> GetAccountsByBranchBL(string searchBranch);
            Task<List<RegularAccount>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate);
            Task<double> GetBalanceBL(string accountNumber);
            Task<bool> UpdateBalanceBL(string accountNumber, double balance);
            Task<bool> UpdateBranchBL(RegularAccount newAccount);
            Task<bool> UpdateAccountTypeBL(RegularAccount newAccount);
            Task<bool> DeleteAccountBL(string deleteAccountNo);
        }
}
