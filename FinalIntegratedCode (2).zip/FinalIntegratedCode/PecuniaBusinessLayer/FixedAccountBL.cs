﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Exceptions;
using Pecunia.Helpers;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting accounts from FixedAccount collection.
    /// </summary>
    public class FixedAccountBL : BLBase<FixedAccount>, IFixedAccountBL, IDisposable
    {
        //fields
        FixedAccountDALBase fixaccountDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public FixedAccountBL()
        {
            this.fixaccountDAL = new FixedAccountDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>

        protected async override Task<bool> Validate(FixedAccount entityObject)
        {

            CustomerBL cbl = new CustomerBL();

            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            Guid custID = entityObject.CustomerID;
            Customer customer = await cbl.GetCustomerByCustomerIDBL(custID);
            String CustomerNo = customer.CustomerNumber;

            //Customer no should be valid
            if ((customer == null))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Customer number is not valid, customer doesn't exists.");
            }

            //Branch should be in (Mumbai,Bengaluru,Delhi,Chennai) 
            if (!(entityObject.Branch.Equals("Mumbai", StringComparison.OrdinalIgnoreCase)) && !(entityObject.Branch.Equals("Bengaluru", StringComparison.OrdinalIgnoreCase))
                && !(entityObject.Branch.Equals("Delhi", StringComparison.OrdinalIgnoreCase)) && !(entityObject.Branch.Equals("Chennai", StringComparison.OrdinalIgnoreCase)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Branch should be one among Mumbai, Chennai, Delhi or Bengaluru");
            }

            //Account Type should be Fixed
            if (!(entityObject.AccountType.Equals("Fixed", StringComparison.OrdinalIgnoreCase)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Account Type not valid");
            }

            //Customer no should not be blank
            if (!(CustomerNo != "") && !(CustomerNo != null))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Customer Number can't be blank");
            }

            //Account Type should not be blank
            if (!(entityObject.AccountType != "") && !(entityObject.AccountType != null))
            {
                valid = false;
                sb.Append(Environment.NewLine + "AccountType can't be blank");
            }

            //Tenure should be greater than zero
            if (!(entityObject.Tenure > 0))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Tenure should be greater than zero");
            }


            //FDDeposit Amount should be greater than zero
            if (!(entityObject.FDDeposit > 0))
            {
                valid = false;
                sb.Append(Environment.NewLine + "FDDeposit Amount should be greater than zero");
            }


            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;

        }


        /// <summary>
        /// Adds new account to Fixed Accounts collection.
        /// </summary>
        /// <param name="newFixed">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new account is added.</returns>
        public async Task<bool> CreateAccountBL(FixedAccount newFixed)
        {
            bool AccountCreated = false;
            try
            {
                if (await Validate(newFixed))
                {
                    await Task.Run(() =>
                    {

                        fixaccountDAL.CreateAccountDAL(newFixed);

                        //Account No generator
                        if (fixaccountDAL.GetAllAccountsDAL().Count == 0)
                        {
                            newFixed.AccountNo = Convert.ToString(AccountsConfiguration.baseAccountNo2);
                        }
                        else
                        {
                            int b = FixedAccountDALBase.fixedAccountList.Count();
                            long nextAccountNo = AccountsConfiguration.baseAccountNo2 + b;
                            newFixed.AccountNo = nextAccountNo.ToString();
                        }


                        AccountCreated = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountCreated;
        }

        /// <summary>
        /// Gets all fixed accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all fixed accounts.</returns>
        public async Task<List<FixedAccount>> GetAllAccountsBL()
        {
            List<FixedAccount> fixedList = null;
            try
            {
                await Task.Run(() =>
                {
                    fixedList = fixaccountDAL.GetAllAccountsDAL();
                });

            }
            catch (Exception)
            {
                throw;
            }
            return fixedList;
        }

        /// <summary>
        /// Gets fixed account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of FixedAccount Class.</returns>
        public async Task<FixedAccount> GetAccountByAccountNoBL(string searchAccountNo)
        {
            FixedAccount searchAccount = null;
            try
            {
                await Task.Run(() =>
                {
                    searchAccount = fixaccountDAL.GetAccountByAccountNoDAL(searchAccountNo);
                });

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;

        }



        /// <summary>
        /// Gets list of fixed accounts based on a particular Customer
        /// </summary>
        /// <param name="searchCustomerID">Contains the Customer ID to search the accounts.</param>
        /// <returns>Returns the list of FixedAccount class objects where the Customer ID matches.</returns>
        public async Task<List<FixedAccount>> GetAccountsByCustomerNoBL(Guid searchCustomerID)
        {

            List<FixedAccount> AccountsByCustNo = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByCustNo = fixaccountDAL.GetAccountsByCustomerNoDAL(searchCustomerID);
                });


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;

        }

        /// <summary>
        /// Gets list of fixed accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Fixed Account class objects.</returns>
        public async Task<List<FixedAccount>> GetAccountsByBranchBL(string searchBranch)
        {

            List<FixedAccount> AccountsByBranch = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByBranch = fixaccountDAL.GetAccountsByBranchDAL(searchBranch);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByBranch;

        }

        /// <summary>
        /// Gets list of fixed accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of FixedAccount class objects.</returns>
        public async Task<List<FixedAccount>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate)
        {

            List<FixedAccount> AccountsByDate = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByDate = fixaccountDAL.GetAccountsByAccountOpeningDateDAL(startDate, endDate);
                });

            }

            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;

        }

        /// <summary>
        /// Gets Current Balance in the fixed account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public async Task<double> GetBalanceBL(string accountNumber)
        {

            double balance = 0;
            try
            {
                await Task.Run(() =>
                {
                    balance = fixaccountDAL.GetBalanceDAL(accountNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return balance;

        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public async Task<bool> UpdateBalanceBL(string accountNumber, double balance)
        {

            bool BalanceUpdated = false;

            try
            {
                if (await GetAccountByAccountNoBL(accountNumber) != null)
                {
                    fixaccountDAL.UpdateBalanceDAL(accountNumber, balance);
                    BalanceUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of a fixed account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public async Task<bool> UpdateBranchBL(FixedAccount updateAccount)
        {
            bool AccountBranchUpdated = false;
            try
            {
                if ((await Validate(updateAccount)) && (await GetAccountByAccountNoBL(updateAccount.AccountNo) != null))
                {

                    this.fixaccountDAL.UpdateBranchDAL(updateAccount);
                    AccountBranchUpdated = true;
                    Serialize();

                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountBranchUpdated;
        }


        /// <summary>
        /// Deletes an existing fixed account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public async Task<bool> DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                if (await GetAccountByAccountNoBL(deleteAccountNo) != null)
                {
                    this.fixaccountDAL.DeleteAccountDAL(deleteAccountNo);
                    AccountDeleted = true;
                    Serialize();
                }
            }

            catch (Exception)
            {
                throw;
            }

            return AccountDeleted;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((FixedAccountDAL)fixaccountDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                FixedAccountDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                FixedAccountDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

