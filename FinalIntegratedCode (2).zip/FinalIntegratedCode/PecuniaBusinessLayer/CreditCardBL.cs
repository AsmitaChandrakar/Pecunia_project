﻿using Pecunia.Entities;

using Pecunia.Exceptions;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Helpers;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating and searching creditcards from CreditCards collection.
    /// </summary>


    public class CreditCardBL : BLBase<CreditCard>, iCreditCardBL, IDisposable
    {
        //fields
        CreditCardDALBase CreditCardDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public CreditCardBL()
        {
            this.CreditCardDAL = new CreditCardDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(CreditCard entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);
            CustomerBL a = new CustomerBL();
           
            //Checks the type of card
            if (entityObject.CardType != "Platinum Plus" && entityObject.CardType != "Visa Signature" && entityObject.CardType != "Infinia")
            {
                valid = false;
                sb.Append(Environment.NewLine + "Card Type should be Platinum Plus  or Visa Signature or Infinia ");

            }
            //Checks status of card
            if (entityObject.CardStatus != "Active" && entityObject.CardStatus != "Blocked")
            {
                valid = false;
                sb.Append(Environment.NewLine + "Card Status should be Active  or Blocked");

            }
            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new CreditCard to Credit Cards collection.
        /// </summary>
        /// <param name="newCreditCard">Contains the CreditCard details to be added.</param>
        /// <returns>Determinates whether the new CreditCard is added.</returns>
        public async Task<bool> AddCreditCardBL(CreditCard newCreditCard)
        {
            bool CreditCardAdded = false;
            try
            {
                if (await Validate(newCreditCard))
                {

                    {
                        

                        //Credit Card No generator
                        if (CreditCardDALBase.creditCardsList.Count == 0)
                        {
                            newCreditCard.CardNumber = Convert.ToString(CardConfiguration.baseCreditCardNumber);
                        }
                        else
                        {
                            int c = CreditCardDALBase.creditCardsList.Count();
                            long nextCardNo = CardConfiguration.baseCreditCardNumber + c;
                            newCreditCard.CardNumber = nextCardNo.ToString();

                        }

                        this.CreditCardDAL.AddCreditCardDAL(newCreditCard);
                        CreditCardAdded = true;
                        Serialize();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return CreditCardAdded;
        }
        /// <summary>
        /// Gets all CreditCards from the collection.
        /// </summary>
        /// <returns>Returns list of all CreditCards.</returns>
        public async Task<List<CreditCard>> GetAllCreditCardsBL()
        {
            List<CreditCard> CreditCardsList = null;
            try
            {
                await Task.Run(() =>
                {
                    CreditCardsList = CreditCardDAL.GetCreditCardListDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return CreditCardsList;
        }
        /// <summary>
        /// Gets CreditCard based on CreditCardID.
        /// </summary>
        /// <param name="searchCreditCardID">Represents CreditCardID to search.</param>
        /// <returns>Returns CreditCard object.</returns>
        public async Task<CreditCard> GetCreditCardByCreditCardNumberBL(string searchCreditCardNumber)
        {
            CreditCard matchingCreditCard = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCreditCard = CreditCardDAL.GetCreditCardByCreditCardNumberDAL(searchCreditCardNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCreditCard;
        }
        /// <summary>
        /// Gets CreditCard based on CustomerID.
        /// </summary>
        /// <param name="Customerid">Represents CreditCardID to search.</param>
        /// <returns>Returns List of credit card objects with same account id.</returns>
        public async Task<List<CreditCard>> GetCreditCardsByCustomerIDBL(Guid CustomerID)
        {
            List<CreditCard> matchingCreditCards = new List<CreditCard>();
            try
            {
                await Task.Run(() =>
                {
                    matchingCreditCards = CreditCardDAL.GetCreditCardsByCustomerIDDAL(CustomerID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCreditCards;
        }
        /// <summary>
        /// Updates credit card status based on CreditCardID.
        /// </summary>
        /// <param name="\updateCreditCard">Represents CreditCrad object for which status is to be updated.</param>
        /// <param name="\card Status">Represents CreditCard ID for which status is to be updated.</param>
        /// <returns>Determinates whether the existing CreditCard's status is updated.</returns>
        public async Task<bool> UpdateCreditCardStatusBL(CreditCard updateCreditCard)
        {
            bool statusUpdated = false;
            try
            {
                if ((await Validate(updateCreditCard)) && (await GetCreditCardByCreditCardNumberBL(updateCreditCard.CardNumber)) != null)
                {
                    this.CreditCardDAL.UpdateCreditCardStatusDAL(updateCreditCard);
                    statusUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return statusUpdated;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((CreditCardDAL)CreditCardDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public void Serialize()
        {
            try
            {
                CreditCardDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public void Deserialize()
        {
            try
            {
                CreditCardDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
