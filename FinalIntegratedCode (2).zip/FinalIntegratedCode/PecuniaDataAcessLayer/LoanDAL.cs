﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Helpers;
using Pecunia.Contracts.DALContracts;
using System.Data.SqlClient;
using System.Data;

namespace Pecunia.DataAcessLayer
{
    public class CarLoanDAL : CarLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds New Car Loan to Loans collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Determinates whether the new Loan is added.</returns>
        public override bool AddCarLoanDAL(CarLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                //Autoimplemented Details

                NewLoan.LoanID = Guid.NewGuid();
                CustomerDAL CD = new CustomerDAL();
                Customer cust = CD.GetCustomerByCustomerNumberDAL(NewLoan.CustomerNumber);


                SqlConnection cn = new SqlConnection("Data Source = ndamssql\\sqlilearn; Initial Catalog = 13th Aug CLoud PT Immersive; User ID = sqluser; Password = sqluser");
                try
                {
                    cn.Open();

                }
                catch (Exception exp)
                {

                }

                string Procedure = "TeamE.CreateCarLoan";

                SqlCommand sqlcmd = new SqlCommand(Procedure);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@CustomerID", cust.CustomerID);
                sqlcmd.Parameters.AddWithValue("@LoanAmount", NewLoan.AmtOfLoan);
                sqlcmd.Parameters.AddWithValue("@LoanDuration", NewLoan.Tenure);
                sqlcmd.Parameters.AddWithValue("@License", NewLoan.License);
                sqlcmd.Connection = cn;

                try
                {
                    sqlcmd.ExecuteNonQuery();


                }
                catch (Exception exp)
                {

                }


                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the List of all Car Loan Applied
        /// </summary>
        /// <returns>Returns List containing Car Loan Information</returns>
        public override List<CarLoan> GetAllCarLoanDAL()
        {
            return CarLoanList;
        }

        /// <summary>
        /// Will Return Information of Car loan based on Loan Number
        /// </summary>
        /// <param name="loanNumber">Will take Loan Number from user</param>
        /// <returns>Car Loan details </returns>
        public override CarLoan GetCarLoanByLoanNumberDAL(string loannumber)
        {
            CarLoan LoanByID = null;
            try
            {
                LoanByID = CarLoanList.Find(x => x.LoanNumber == loannumber);

                if (LoanByID == null)
                {
                    //catch error to show no loan found
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return Information of loan based on CustomerNumber
        /// </summary>
        /// <param name="CustomerNumber">Will take Customer Number from user</param>
        /// <returns>Loan details</returns>
        public override CarLoan GetCarLoanByCustomerDAL(string customernumber)
        {
            CarLoan LoanByID = null;
            try
            {
                LoanByID = CarLoanList.Find(x => x.CustomerNumber == customernumber);

                if (LoanByID == null)
                {
                    //catch error to show no loan found
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return Information of loan based on License Number
        /// </summary>
        /// <param name="licensenumber">Will take licensenumber from user</param>
        /// <returns>Loan details</returns>    
        public override CarLoan GetCarLoanByLicenseDAL(string licensenumber)
        {
            CarLoan LoanByID = null;
            try
            {
                LoanByID = CarLoanList.Find(x => x.License == licensenumber);

            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List</returns>
        public override List<CarLoan> GetCarLoanByLoanStatusDAL(string LoanStatus)
        {
            List<CarLoan> loanlist = null;
            try
            {

                loanlist = CarLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Method to Update Loan 
        /// </summary>
        /// <param name="Updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether loan is updated or not </returns>
        public override bool UpdateCarLoanDAL(CarLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find CarLoan based on carLoanID
                CarLoan matchingloan = GetCarLoanByLoanNumberDAL(updatedloan.LoanNumber);

                if (matchingloan != null)
                {
                    //Update CarLoan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "Tenure", "CustomerNumber", "LoanNumber", "LoanStatus", "License" });
                    update = true;
                }
                else
                {
                    //catch error no loan found
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }

        /// <summary>
        ///Delete Car Loan 
        /// </summary>
        /// <param name="deleteLoannumber"></param>
        /// <returns>Will return wether loan is deleted or not</returns>
        public override bool DeleteCarLoanDAL(string deleteLoannumber)
        {
            bool LoanDeleted = false;
            CarLoan LoanByID = GetCarLoanByLoanNumberDAL(deleteLoannumber);
            try
            {
                if (LoanByID != null)
                {
                    Console.WriteLine(LoanByID.LoanNumber);
                    CarLoanList.Remove(LoanByID);
                    LoanDeleted = true;
                }
                else
                {
                    //catch error no loan found
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        /// <summary>
        /// To calculate wether person is eligible for loan or not 
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <returns></returns>
        public override bool GetCarEligibility(string loanNumber)
        {
            CustomerDAL cd = new CustomerDAL();
            bool status = false;
            CarLoan loan = GetCarLoanByLoanNumberDAL(loanNumber);
            Customer cust = cd.GetCustomerByCustomerNumberDAL(loan.CustomerNumber);
            if ((cust != null) && (loan != null))
            {
                if ((cust.AnnualIncome) * 5 >= loan.AmtOfLoan)
                {
                    status = true;
                }

            }
            return status;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {

        }
    }

    public class HomeLoanDAL : HomeLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Home Loan to  Loan collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>whether the new Loan is added.</returns>
        public override bool AddHomeLoanDAL(HomeLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                //Add Basic Details
                double carbase = 1000000001 + HomeLoanList.Count();
                NewLoan.LoanNumber = "HL" + carbase.ToString();
                NewLoan.LoanType = "Home";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                HomeLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<HomeLoan> GetAllHomeLoanDAL()
        {
            return HomeLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan Number
        /// </summary>
        /// <param name="loanID">Will take loan Number from user</param>
        /// <returns>Return Home Loan details</returns>
        public override HomeLoan GetHomeLoanByLoanNumberDAL(string loannumber)
        {
            HomeLoan LoanByID = null;
            try
            {
                LoanByID = HomeLoanList.Find(x => x.LoanNumber == loannumber);

                if (LoanByID == null)
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return Information of loan based on Customer Number
        /// </summary>
        /// <param name="loanID">Will take Customer Number from user</param>
        /// <returns>Will return Home Loan details</returns>
        public override HomeLoan GetHomeLoanByCustomerDAL(string customernumber)
        {
            HomeLoan LoanByID = null;
            try
            {
                LoanByID = HomeLoanList.Find(x => x.CustomerNumber == customernumber);

                if (LoanByID == null)
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List of home loan details</returns>
        public override List<HomeLoan> GetHomeLoanByLoanStatusDAL(string LoanStatus)
        {
            List<HomeLoan> loanlist = null;
            try
            {

                loanlist = HomeLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Method to Update Loan 
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether bool is updated or not </returns>
        public override bool UpdateHomeLoanDAL(HomeLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanNumber
                HomeLoan matchingloan = GetHomeLoanByLoanNumberDAL(updatedloan.LoanNumber);

                if (matchingloan != null)
                {
                    //Update loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "Tenure", "CustomerNumber", "LoanNumber", "LoanStatus", "Collateral" });
                    update = true;
                }
                else
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }

        /// <summary>
        ///Will Delete Home Loan details 
        /// </summary>
        /// <param name="deleteloannumber"></param>
        /// <returns></returns>
        public override bool DeleteHomeLoanDAL(string deleteloannumber)
        {
            bool LoanDeleted = false;
            HomeLoan LoanByID = GetHomeLoanByLoanNumberDAL(deleteloannumber);
            try
            {
                if (LoanByID != null)
                {
                    HomeLoanList.Remove(LoanByID);
                    LoanDeleted = true;
                }
                else
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        /// <summary>
        ///Will Return wether person is eligible for home loan 
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <returns></returns>
        public override bool GetHomeEligibility(string loanNumber)
        {
            CustomerDAL cd = new CustomerDAL();
            bool status = false;
            HomeLoan loan = GetHomeLoanByLoanNumberDAL(loanNumber);
            Customer cust = cd.GetCustomerByCustomerNumberDAL(loan.CustomerNumber);
            if ((cust != null) && (loan != null))
            {
                if (((cust.AnnualIncome) * 10 >= loan.AmtOfLoan) && loan.AmtOfLoan < loan.Collateral)
                {
                    status = true;
                }

            }
            return status;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {

        }
    }

    public class PersonalLoanDAL : PersonalLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Personal Loan to Loan collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Return whether the new Loan is added.</returns>
        public override bool AddPersonalLoanDAL(PersonalLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                double carbase = 1000000001 + PersonalLoanList.Count();
                NewLoan.LoanNumber = "PL" + carbase.ToString();
                NewLoan.LoanType = "Personal";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                PersonalLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Personal Loan Applied
        /// </summary>
        /// <returns>Returns List containing Personal Loan Information</returns>
        public override List<PersonalLoan> GetAllPersonalLoanDAL()
        {
            return PersonalLoanList;
        }

        /// <summary>
        /// Will Return Information of Personal loan based on loan number
        /// </summary>
        /// <param name="loanID">Will take Personal loan number from user</param>
        /// <returns>Will return Personal Loan</returns>
        public override PersonalLoan GetPersonalLoanByLoanNumberDAL(string loannumber)
        {
            PersonalLoan LoanByID = null;
            try
            {
                LoanByID = PersonalLoanList.Find(x => x.LoanNumber == loannumber);
                if (LoanByID == null)
                {
                    //Catch Error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return Personal Loan details based on customernumber
        /// </summary>
        /// <param name="loannumber"></param>
        /// <returns></returns>
        public override PersonalLoan GetPersonalLoanByCustomerDAL(string customernumber)
        {
            PersonalLoan LoanByID = null;
            try
            {
                LoanByID = PersonalLoanList.Find(x => x.CustomerNumber == customernumber);
                if (LoanByID == null)
                {
                    //Catch Error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }


        /// <summary>
        /// Will Return list of Personal loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List of Personal loan status</returns>
        public override List<PersonalLoan> GetPersonalLoanByLoanStatusDAL(string LoanStatus)
        {
            List<PersonalLoan> loanlist = null;
            try
            {

                loanlist = PersonalLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Method to Update Personal Loan 
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Personal Loan</param>
        /// <returns>Wether personal loan is updated or not </returns>
        public override bool UpdatePersonalLoanDAL(PersonalLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanID
                PersonalLoan matchingloan = GetPersonalLoanByLoanNumberDAL(updatedloan.LoanNumber);

                if (matchingloan != null)
                {
                    //Update Loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "Tenure", "CustomerNumber", "LoanNumber", "LoanStatus", "Collateral" });
                    update = true;
                }
                else
                {
                    //Catch Error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }

        /// <summary>
        ///Delete Personal Loan based on loan number 
        /// </summary>
        /// <param name="deleteLoannumber"></param>
        /// <returns>Wether Personal loan is deleted or not</returns>
        public override bool DeletePersonalLoanDAL(string deleteLoannumber)
        {
            bool LoanDeleted = false;
            PersonalLoan LoanByID = GetPersonalLoanByLoanNumberDAL(deleteLoannumber);
            try
            {
                if (LoanByID != null)
                {
                    PersonalLoanList.Remove(LoanByID);
                    LoanDeleted = true;
                }
                else
                {

                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        /// <summary>
        /// will decide wether person is eligible for Personal loan or not
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <returns></returns>
        public override bool GetPersonalEligibility(string loanNumber)
        {
            CustomerDAL cd = new CustomerDAL();
            bool status = false;
            PersonalLoan loan = GetPersonalLoanByLoanNumberDAL(loanNumber);
            Customer cust = cd.GetCustomerByCustomerNumberDAL(loan.CustomerNumber);
            if ((cust != null) && (loan != null))
            {
                if (((cust.AnnualIncome) * 5 >= loan.AmtOfLoan) && loan.AmtOfLoan < loan.Collateral)
                {
                    status = true;
                }

            }
            return status;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {

        }
    }

    public class EducationLoanDAL : EducationLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Education Loan to Loan collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new education loan to be added.</param>
        /// <returns>Determinates whether the new education Loan is added.</returns>
        public override bool AddEducationLoanDAL(EducationLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                double carbase = 1000000001 + EducationLoanList.Count();
                NewLoan.LoanNumber = "EL" + carbase.ToString();
                NewLoan.LoanType = "Education";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                EducationLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Education Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<EducationLoan> GetAllEducationLoanDAL()
        {
            return EducationLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan number
        /// </summary>
        /// <param name="loanID">Will take loan number from user</param>
        /// <returns>Will return loan details</returns>
        public override EducationLoan GetEducationLoanByLoanNumberDAL(string loanNumber)
        {
            EducationLoan LoanByID = null;
            try
            {
                LoanByID = EducationLoanList.Find(x => x.LoanNumber == loanNumber);
                if (LoanByID == null)
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return Information of loan based on customernumber
        /// </summary>
        /// <param name="loanID">Will take loan ID from user</param>
        /// <returns>Loan Related Information</returns>
        public override EducationLoan GetEduLoanByCustomerDAL(string CustomerNumber)
        {
            EducationLoan LoanByID = null;
            try
            {
                LoanByID = EducationLoanList.Find(x => x.CustomerNumber == CustomerNumber);
                if (LoanByID == null)
                {
                    //catch error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return  List of Education Loan</returns>
        public override List<EducationLoan> GetEducationLoanByLoanStatusDAL(string LoanStatus)
        {
            List<EducationLoan> loanlist = null;
            try
            {

                loanlist = EducationLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Method to Update Education Loan 
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of Updated Loan</param>
        /// <returns>Wether Education Loan is updated or not </returns>
        public override bool UpdateEducationLoanDAL(EducationLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanID
                EducationLoan matchingloan = GetEducationLoanByLoanNumberDAL(updatedloan.LoanNumber);

                if (matchingloan != null)
                {
                    //Update Loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "Tenure", "CustomerNumber", "LoanNumber", "LoanStatus", "Collateral", "Sponseror", "CollegeName", "AdmissionID" });
                    update = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }

        /// <summary>
        /// Delete Education Loan based on loan number
        /// </summary>
        /// <param name="deleteLoannumber"></param>
        /// <returns></returns>
        public override bool DeleteEducationLoanDAL(string deleteLoannumber)
        {
            bool LoanDeleted = false;
            EducationLoan LoanByID = GetEducationLoanByLoanNumberDAL(deleteLoannumber);
            try
            {
                if (LoanByID != null)
                {
                    EducationLoanList.Remove(LoanByID);
                    LoanDeleted = true;
                }
                else
                {
                    //Catch Error
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        /// <summary>
        /// Will return wether person is eligible for loan or not
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <returns></returns>
        public override bool GetEducationEligibility(string loanNumber)
        {
            CustomerDAL cd = new CustomerDAL();
            bool status = false;
            EducationLoan loan = GetEducationLoanByLoanNumberDAL(loanNumber);
            Customer cust = cd.GetCustomerByCustomerNumberDAL(loan.CustomerNumber);
            if ((cust != null) && (loan != null))
            {
                if (loan.AmtOfLoan < loan.Collateral)
                {
                    status = true;
                }

            }
            return status;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {

        }
    }

}
