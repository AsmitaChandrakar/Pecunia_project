﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Pecunia.Helpers;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting account from Fixed Accounts collection.
    /// </summary>
    public class FixedAccountDAL : FixedAccountDALBase, IDisposable
    {

        /// <summary>
        /// Adds new account to FixedAccount collection.
        /// </summary>
        /// <param name="newFixed">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new account is added.</returns>
        public override bool CreateAccountDAL(FixedAccount newFixed)
        {
            bool AccountCreated = false;
            try
            {

                SqlConnection cn = new SqlConnection("data source=IN-MUM-TRN033; integrated security=yes");
                SqlCommand cmd = new SqlCommand($"INSERT INTO PecuniaBanking.CustomerService.FixedAccount.VALUES(newid(),newid(),'2000000001',0,'Fixed','Mumbai',10,20000000,'Active',500,3.5, {newFixed.CreationDateTime}, {newFixed.LastModifiedDateTime})",cn);

                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
                
                newFixed.AccountID = Guid.NewGuid();
                newFixed.CreationDateTime = DateTime.Now;
                newFixed.LastModifiedDateTime = DateTime.Now;
                newFixed.InterestRate = AccountsConfiguration.interest;
                newFixed.MinimumBalance = AccountsConfiguration.minbal;
                newFixed.CurrentBalance = 0;
                
                fixedAccountList.Add(newFixed);
                AccountCreated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return AccountCreated;

        }

        /// <summary>
        /// Gets all fixed accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all fixed accounts.</returns>
        public override List<FixedAccount> GetAllAccountsDAL()
        {
            return fixedAccountList;
        }

        /// <summary>
        /// Gets fixed account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of Fixed Account Class.</returns>
        public override FixedAccount GetAccountByAccountNoDAL(string searchAccountNo)
        {
            FixedAccount searchAccount = null;
            try
            {
                searchAccount = fixedAccountList.Find(x => x.AccountNo == searchAccountNo);

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;
        }


        /// <summary>
        /// Gets list of fixed accounts based on CustomerNo
        /// </summary>
        /// <param name="searchCustomerID">Contains the Customer ID to search the accounts.</param>
        /// <returns>Returns the list of Fixed Account class objects where the Customer No matches.</returns>
        public override List<FixedAccount> GetAccountsByCustomerNoDAL(Guid searchCustomerID)
        {
            List<FixedAccount> AccountsByCustNo = new List<FixedAccount>();
            try
            {

                AccountsByCustNo.AddRange(fixedAccountList.FindAll(x => x.CustomerID == searchCustomerID));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;
        }


        /// <summary>
        /// Gets list of fixed accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the fixed account in a particular branch.</param>
        /// <returns>Returns the list of Fixed Account class objects.</returns>
        public override List<FixedAccount> GetAccountsByBranchDAL(string searchBranch)
        {
            List<FixedAccount> AccountsByBranch = new List<FixedAccount>();
            try
            {
                AccountsByBranch.AddRange(fixedAccountList.FindAll(x => x.Branch == searchBranch));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByBranch;
        }

        /// <summary>
        /// Gets list of fixed accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of FixedAccount class objects.</returns>
        public override List<FixedAccount> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate)
        {
            List<FixedAccount> AccountsByDate = new List<FixedAccount>();
            try
            {
                foreach (FixedAccount item in fixedAccountList)
                {
                    if ((item.CreationDateTime.Ticks >= startDate.Ticks) && (item.CreationDateTime.Ticks <= endDate.Ticks))
                    {
                        AccountsByDate.Add(item);
                    }
                }


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;
        }

        /// <summary>
        /// Gets Current Balance in the fixed account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public override double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;

            try
            {

                FixedAccount fixedacc;
                fixedacc = fixedAccountList.Find(x => x.AccountNo == accountNumber);
                balance = fixedacc.CurrentBalance;
            }
            catch (Exception)
            {
                throw;
            }
            return balance;
        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public override bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;

            try
            {
                FixedAccount fixedacc;
                fixedacc = fixedAccountList.Find(x => x.AccountNo == accountNumber);
                /* int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                 int st = int.Parse(account.DateOfAccountOpening.ToString("yyyyMMdd"));
                 double yr = (now - st) / 10000;
                 double si = (balance * account.InterestRate * yr) / 100;*/
                fixedacc.CurrentBalance = balance;
                fixedacc.LastModifiedDateTime = DateTime.Now;
                BalanceUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of a fixed account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public override bool UpdateBranchDAL(FixedAccount updateAccount)
        {
            bool AccountBranchUpdated = false;

            try
            {
                FixedAccount matchingAccount = GetAccountByAccountNoDAL(updateAccount.AccountNo);
                if (matchingAccount != null)
                {
                    //Update account details
                    ReflectionHelpers.CopyProperties(updateAccount, matchingAccount, new List<string>() { "Branch" });
                    //matchingAccount.Branch = updateAccount.Branch;
                    matchingAccount.LastModifiedDateTime = DateTime.Now;
                    AccountBranchUpdated = true;
                }

            }
            catch (Exception)
            {
                throw;
            }
            return AccountBranchUpdated;
        }

        /// <summary>
        /// Deletes an existing fixed account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public override bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;

            try
            {
                FixedAccount deleteAccount = null;
                FixedAccount fixed1;
                fixed1 = fixedAccountList.Find(x => x.AccountNo == deleteAccountNo);
                fixed1.LastModifiedDateTime = DateTime.Now;
                fixed1.Status = "Closed";
                fixed1.CurrentBalance = 0.0;
                deleteAccount = fixed1;

                if (deleteAccountNo != null)
                {

                    AccountDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return AccountDeleted;

        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        /// 
        public void Dispose()
        {
            throw new NotImplementedException();
        }

    }
}
