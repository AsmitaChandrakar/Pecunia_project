﻿using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.DataAcessLayer
{/// <summary>
 /// Contains  methods for inserting, updating and searching debitcards from ChequeBooks collection.
 /// </summary>

    public class ChequeBookDAL : ChequeBookDALBase, IDisposable
    { /// <summary>
      /// Adds new chequeBook to ChequeBooks collection.
      /// </summary>
      /// <param name="chequeBook">Contains the chequebook details to be added.</param>
      /// <returns>Determines whether the new   cheque book is requested.</returns>
        public override bool AddChequeBookDAL(ChequeBook chequeBook)
        {
            bool chequeBookIssued = false;
            try
            {
                chequeBook.ChequeBookID = Guid.NewGuid();
                chequeBook.ChequeBookStatus = "Requested";
                chequeBooksList.Add(chequeBook);
                chequeBookIssued = true;
            }
            catch (Exception)
            {
                throw;
            }
            return chequeBookIssued;

        }
        /// <summary>
        /// Returns chequeBook list
        /// </summary>
        /// <returns> Returns the list of chequeBooks</returns>
        public override List<ChequeBook> GetChequeBookListDAL()
        {
            return chequeBooksList;
        }


        /// <summary>
        /// Updates the status of debit card
        /// </summary>
        /// <param name="chequeBookID">Contains the chequeBookID for which we need to change status</param>

        /// <returns>Returns bool value if updated or not</returns>
        public override bool UpdateChequeBookStatusDAL(ChequeBook chequeBook)
        {
            bool chequeBookStatusChanged = false;
            try
            {
                ChequeBook matchingChequeBook = GetChequeBookByChequeBookIDDAL(chequeBook.ChequeBookID);

                if (matchingChequeBook != null)
                {
                    //Update chequeBook details

                    matchingChequeBook.ChequeBookStatus = "Approved";
                    matchingChequeBook.LastModifiedDate = DateTime.Now;

                    chequeBookStatusChanged = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return chequeBookStatusChanged;
        }
        /// <summary>
        /// Gets chequeBook based on chequeBookID.
        /// </summary>
        /// <param name="debitID">Represents ChequeBookID to search.</param>
        /// <returns>returns cheque book details for respective cheque book ID</returns>
        public override ChequeBook GetChequeBookByChequeBookIDDAL(Guid chequeBookID)
        {
            ChequeBook searchChequeBook = null;
            try
            {
                searchChequeBook = chequeBooksList.Find(x => x.ChequeBookID == chequeBookID);
            }
            catch (Exception)
            {
                throw;
            }
            return searchChequeBook;
        }
        public override ChequeBook GetChequeBookBySeriesStartDAL(double seriesStart)
        {
            ChequeBook searchChequeBook = null;
            try
            {
                searchChequeBook = chequeBooksList.Find(x => x.SeriesStart == seriesStart);
            }
            catch (Exception)
            {
                throw;
            }
            return searchChequeBook;
        }
        /// <summary>
        /// Gets list of chequeBooks based on AccountID.
        /// </summary>
        /// <param name="accountID">Represents AccountID to search.</param>
        /// <returns>returns list of cheque books details for respective AccountID</returns>
        public override List<ChequeBook> GetChequeBooksByAccountIDDAL(Guid accountID)
        {
            List<ChequeBook> ChequeBooksByAccountID = new List<ChequeBook>();
            try
            {

                ChequeBooksByAccountID.AddRange(chequeBooksList.FindAll(x => x.AccountID == accountID));

            }
            catch (Exception)
            {
                throw;
            }
            return ChequeBooksByAccountID;
        }

        public override List<ChequeBook> GetChequeBooksByAccountIDAndStatusDAL(Guid accountID, string status)
        {
            List<ChequeBook> RequestedChequeBooksByAccountID = new List<ChequeBook>();

            try
            {
                foreach (ChequeBook item in chequeBooksList)

                    if (item.AccountID == accountID && item.ChequeBookStatus == status)
                    {
                        RequestedChequeBooksByAccountID.Add(item);
                    }
            }
            catch (Exception)
            {
                throw;
            }
            return RequestedChequeBooksByAccountID;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}
