import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { EmployeeHomeComponent } from './employee-home/employee-home.component';
import { CustomersComponent } from './customers/customers.component';
import { EmployeeRoutingModule } from './employee-routing.module';
import { NewOrderComponent } from './new-order/new-order.component';

@NgModule({
  declarations: [
    EmployeeHomeComponent,
    CustomersComponent,
    NewOrderComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EmployeeRoutingModule
  ],
  exports: [
    EmployeeRoutingModule,
    EmployeeHomeComponent,
    CustomersComponent,
    NewOrderComponent
  ]
})
export class EmployeeModule { }

