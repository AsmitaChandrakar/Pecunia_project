﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    public class Customer
    {
        private string customerID;
        public string  CustomerID { get => customerID; set => customerID = value; }
       

        private string customerName;
        public string CustomerName { get => customerName; set => customerName = value; }
       
       

        private string customerContactNumber;
        public string CustomerContactNumber { get => customerContactNumber; set => customerContactNumber = value; }
       

        private string customerEmailID;
        public string CustomerEmailID { get => customerEmailID; set => customerEmailID = value; }
       

        private string customerAddress;
        public string CustomerAddress { get => customerAddress; set => customerAddress = value; }
       

        private DateTime customerDOB;
        public DateTime CustomerDOB { get => customerDOB; set => customerDOB = value; }
       

        private string customerPANno;
        public string CustomerPANno { get => customerPANno; set => customerPANno = value; }
        

        private double customerAadharno;
        public double CustomerAadharno { get => customerAadharno; set => customerAadharno = value; }
       

        private string customerGender;
        public string CustomerGender { get => customerGender; set => customerGender = value; }



        //Default constructor
        public Customer()
        {
            CustomerID = string.Empty;
            CustomerName = string.Empty;
            CustomerContactNumber = string.Empty;
            CustomerEmailID = string.Empty;
            CustomerAddress = string.Empty;
            CustomerDOB = DateTime.Now;
            CustomerPANno = string.Empty;
            CustomerAadharno = 0;


        }
    }
        
}
