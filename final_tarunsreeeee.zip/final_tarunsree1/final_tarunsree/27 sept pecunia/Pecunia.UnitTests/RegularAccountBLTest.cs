﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.BusinessLayer;
using Pecunia.Entities;

namespace Pecunia.UnitTests
{   [TestClass]
    class RegularAccountBLTest
    {
        /// <summary>
        /// Create and add a new regular account to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task CreateValidRegularAccount()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() {CustomerNo = "100001", AccountType = "Savings", Branch = "Delhi"};
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Customer No can't be null
        /// </summary>
        [TestMethod]
        public async Task CustomerNoCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = null, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Type can't be null
        /// </summary>
        [TestMethod]
        public async Task AccountTypeCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100002", AccountType = null, Branch = "Delhi"};
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch can't be null
        /// </summary>
        [TestMethod]
        public async Task BranchCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = null }; 
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Customer No should be a 6 digit no starting with 1
        /// </summary>
        [TestMethod]
        public async Task CustomerNoRegExp()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "21267443", AccountType = "Savings", Branch = "Bengaluru" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru")
        /// </summary>
        [TestMethod]
        public async Task BranchShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Kolkata" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }
}

   