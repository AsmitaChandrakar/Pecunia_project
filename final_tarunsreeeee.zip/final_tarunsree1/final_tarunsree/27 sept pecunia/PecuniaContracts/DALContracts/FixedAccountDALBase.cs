﻿using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.DALContracts
{
    public abstract class FixedAccountDALBase
    {
        //Collection of Fixed Accounts
        public static List<FixedAccount> fixedAccountList = new List<FixedAccount>();
        private static string fileName = "fixedaccounts.json";

        //Method for CRUD operations
        public abstract bool CreateAccountDAL(FixedAccount newFixed);
        public abstract List<FixedAccount> GetAllAccountsDAL();
        public abstract FixedAccount GetAccountByAccountNoDAL(string searchAccountNo);
        public abstract List<FixedAccount> GetAccountsByCustomerNoDAL(string searchCustomerNo);
        public abstract List<FixedAccount> GetAccountsByBranchDAL(string searchBranch);
        public abstract List<FixedAccount> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate);
        public abstract double GetBalanceDAL(string accountNumber);
        public abstract bool UpdateBalanceDAL(string accountNumber, double balance);
        public abstract bool UpdateBranchDAL(string accountNumber, string branch);
        public abstract bool DeleteAccountDAL(string deleteAccountNo);

        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public static void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(fixedAccountList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }

        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var fixedListFromFile = JsonConvert.DeserializeObject<List<FixedAccount>>(fileContent);
                if (fixedListFromFile != null)
                {
                    fixedAccountList = fixedListFromFile;
                }
            }
        }

        /// <summary>
        /// Static Constructor.
        /// </summary>
        static FixedAccountDALBase()
        {
            Deserialize();
        }
    }

}
