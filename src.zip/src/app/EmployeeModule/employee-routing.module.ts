import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {EmployeeHomeComponent } from './employee-home/employee-home.component';
import { CustomersComponent } from './customers/customers.component';
import { NewOrderComponent } from './new-order/new-order.component';

const routes: Routes = [
  { path: "home", component: EmployeeHomeComponent },
  { path: "customers", component: CustomersComponent },
  { path: "neworder", component: NewOrderComponent },
  { path: "**", redirectTo: '/home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeRoutingModule { }


